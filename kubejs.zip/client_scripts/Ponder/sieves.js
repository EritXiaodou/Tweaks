Ponder.registry((event) => {
    event.create('#forge:sieves').scene("kubejs:sieves", "筛矿", (scene) => {
        scene.showBasePlate()
        scene.idleSeconds(1)
        scene.addKeyframe()
        scene.world.setBlocks([2, 1, 2], "exnihilosequentia:oak_sieve")
        scene.world.showSection([2, 1, 2], Direction.DOWN)
        scene.idleSeconds(1)
        scene.text(15, "这是一个筛子", [2.5, 1.75, 2.5])
        scene.idleSeconds(1)
        scene.text(20, "使用右键装填筛网", [2.5, 1.75, 2.5])
        scene.showControls(20, [2, 1.5, 2], "left")
            .rightClick()
            .withItem('#forge:meshs')
        scene.idleSeconds(1)
        scene.world.modifyBlock([2, 1, 2], (state) => state.with("mesh", "string"), false)
        scene.addKeyframe()
        scene.idleSeconds(1)
        scene.text(20, "手持需要筛制的物品右击筛子", [2.5, 1.75, 2.5])
        scene.showControls(15, [2, 1.5, 2], "left")
            .rightClick()
            .withItem('minecraft:gravel')
        scene.idleSeconds(1)
        scene.world.modifyTileNBT([2, 1, 2], (nbt) => {
            nbt.block = {
                Count: 1,
                id: "minecraft:gravel"
            }
        })
        scene.idleSeconds(1)
        scene.text(15, "再次点击右键", [2.5, 1.75, 2.5]).attachKeyFrame()
        scene.showControls(20, [2, 1.5, 2], "left")
            .rightClick()
        scene.idleSeconds(1)
        scene.world.modifyTileNBT([2, 1, 2], (nbt) => {
            nbt.block = {
                Count: 1,
                id: "minecraft:air"
            }
        })
        scene.world.createItemEntity([2.5, 2.15, 2.5], Direction.DOWN, "exnihilosequentia:iron_pieces")
        scene.world.removeEntity(scene.world.createItemEntity([2.5, 0, 2.5], Direction.DOWN, "exnihilosequentia:iron_pieces"))
        scene.idleSeconds(2)
        scene.world.setBlocks([2, 1, 2], "minecraft:air", true)
        scene.idleSeconds(1)
        scene.world.setBlocks([0, 1, 0, 4, 1, 4], "exnihilosequentia:oak_sieve")
        scene.world.showSection([0, 1, 0, 4, 1, 4], Direction.DOWN)
        scene.addKeyframe()
        scene.idleSeconds(1)
        scene.world.modifyBlock([0, 1, 0], (state) => state.with("mesh", "iron"), false)
        scene.idle(2)
        scene.world.modifyBlock([0, 1, 1], (state) => state.with("mesh", "iron"), false)
        scene.idle(2)
        scene.world.modifyBlock([0, 1, 2], (state) => state.with("mesh", "iron"), false)
        scene.idle(2)
        scene.world.modifyBlock([0, 1, 3], (state) => state.with("mesh", "iron"), false)
        scene.idle(2)
        scene.world.modifyBlock([0, 1, 4], (state) => state.with("mesh", "iron"), false)
        scene.idle(2)
        scene.world.modifyBlock([1, 1, 0], (state) => state.with("mesh", "iron"), false)
        scene.idle(2)
        scene.world.modifyBlock([1, 1, 1], (state) => state.with("mesh", "iron"), false)
        scene.idle(2)
        scene.world.modifyBlock([1, 1, 2], (state) => state.with("mesh", "iron"), false)
        scene.idle(2)
        scene.world.modifyBlock([1, 1, 3], (state) => state.with("mesh", "iron"), false)
        scene.idle(2)
        scene.world.modifyBlock([1, 1, 4], (state) => state.with("mesh", "iron"), false)
        scene.idle(2)
        scene.world.modifyBlock([2, 1, 0], (state) => state.with("mesh", "iron"), false)
        scene.idle(2)
        scene.world.modifyBlock([2, 1, 1], (state) => state.with("mesh", "iron"), false)
        scene.idle(2)
        scene.world.modifyBlock([2, 1, 2], (state) => state.with("mesh", "iron"), false)
        scene.idle(2)
        scene.world.modifyBlock([2, 1, 3], (state) => state.with("mesh", "iron"), false)
        scene.idle(2)
        scene.world.modifyBlock([2, 1, 4], (state) => state.with("mesh", "iron"), false)
        scene.idle(2)
        scene.world.modifyBlock([3, 1, 0], (state) => state.with("mesh", "iron"), false)
        scene.idle(2)
        scene.world.modifyBlock([3, 1, 1], (state) => state.with("mesh", "iron"), false)
        scene.idle(2)
        scene.world.modifyBlock([3, 1, 2], (state) => state.with("mesh", "iron"), false)
        scene.idle(2)
        scene.world.modifyBlock([3, 1, 3], (state) => state.with("mesh", "iron"), false)
        scene.idle(2)
        scene.world.modifyBlock([3, 1, 4], (state) => state.with("mesh", "iron"), false)
        scene.idle(2)
        scene.world.modifyBlock([4, 1, 0], (state) => state.with("mesh", "iron"), false)
        scene.idle(2)
        scene.world.modifyBlock([4, 1, 1], (state) => state.with("mesh", "iron"), false)
        scene.idle(2)
        scene.world.modifyBlock([4, 1, 2], (state) => state.with("mesh", "iron"), false)
        scene.idle(2)
        scene.world.modifyBlock([4, 1, 3], (state) => state.with("mesh", "iron"), false)
        scene.idle(2)
        scene.world.modifyBlock([4, 1, 4], (state) => state.with("mesh", "iron"), false)
        scene.idleSeconds(1)
        scene.text(15, "可以同时使用多个筛子进行筛制工作", [2.5, 1.75, 2.5])
        scene.idleSeconds(1)
        scene.world.modifyTileNBT([0, 1, 0, 4, 1, 4], (nbt) => {
            nbt.block = {
                Count: 1,
                id: "minecraft:gravel"
            }
        })
        scene.showControls(5, [2, 1.5, 2], "left")
            .rightClick()
        scene.idle(5)
        scene.world.modifyTileNBT([0, 1, 0, 4, 1, 4], (nbt) => {
            nbt.block = {
                Count: 1,
                id: "minecraft:air"
            }
        })
        scene.showControls(5, [2, 1.5, 2], "left")
            .rightClick()
        scene.idle(5)
        scene.world.modifyTileNBT([0, 1, 0, 4, 1, 4], (nbt) => {
            nbt.block = {
                Count: 1,
                id: "minecraft:gravel"
            }
        })
        scene.showControls(5, [2, 1.5, 2], "left")
            .rightClick()
        scene.idle(5)
        scene.world.modifyTileNBT([0, 1, 0, 4, 1, 4], (nbt) => {
            nbt.block = {
                Count: 1,
                id: "minecraft:air"
            }
        })
        scene.showControls(5, [2, 1.5, 2], "left")
            .rightClick()
        scene.idle(5)
        scene.world.modifyTileNBT([0, 1, 0, 4, 1, 4], (nbt) => {
            nbt.block = {
                Count: 1,
                id: "minecraft:gravel"
            }
        })
        scene.showControls(5, [2, 1.5, 2], "left")
            .rightClick()
        scene.idle(5)
        scene.world.modifyTileNBT([0, 1, 0, 4, 1, 4], (nbt) => {
            nbt.block = {
                Count: 1,
                id: "minecraft:air"
            }
        })
        scene.showControls(5, [2, 1.5, 2], "left")
            .rightClick()
        scene.idle(5)
        scene.world.modifyTileNBT([0, 1, 0, 4, 1, 4], (nbt) => {
            nbt.block = {
                Count: 1,
                id: "minecraft:gravel"
            }
        })
        scene.showControls(5, [2, 1.5, 2], "left")
            .rightClick()
        scene.idle(5)
        scene.world.modifyTileNBT([0, 1, 0, 4, 1, 4], (nbt) => {
            nbt.block = {
                Count: 1,
                id: "minecraft:air"
            }
        })
        scene.idleSeconds(1)
    })
})