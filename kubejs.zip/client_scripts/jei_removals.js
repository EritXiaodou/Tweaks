JEIEvents.hideItems(event => {
  Color.DYE.forEach(color => {
    ['controller', 'creative_controller', 'grid', 'crafting_grid', 'pattern_grid', 'fluid_grid', 'network_receiver', 'network_transmitter', 'relay', 'detector', 'security_manager', 'wireless_transmitter', 'disk_manipulator', 'crafter', 'crafter_manager', 'crafting_monitor'].forEach(machine => {
      event.hide(`refinedstorage:${color}_${machine}`)
    })
  })
  Color.DYE.forEach(color => {
    ['hopper_botany_pot', 'botany_pot'].forEach(machine => {
      event.hide(`botanypots:${color}_terracotta_${machine}`)
      event.hide(`botanypots:${color}_glazed_terracotta_${machine}`)
      event.hide(`botanypots:${color}_concrete_${machine}`)
      event.hide(`botanypotstiers:elite_${color}_terracotta_${machine}`)
      event.hide(`botanypotstiers:ultra_${color}_terracotta_${machine}`)
      event.hide(`botanypotstiers:creative_${color}_terracotta_${machine}`)
      event.hide(`botanypotstiers:elite_${color}_glazed_terracotta_${machine}`)
      event.hide(`botanypotstiers:ultra_${color}_glazed_terracotta_${machine}`)
      event.hide(`botanypotstiers:creative_${color}_glazed_terracotta_${machine}`)
      event.hide(`botanypotstiers:elite_${color}_concrete_${machine}`)
      event.hide(`botanypotstiers:ultra_${color}_concrete_${machine}`)
      event.hide(`botanypotstiers:creative_${color}_concrete_${machine}`)
      event.hide(`botanypots:terracotta_botany_pot`)
      event.hide(`botanypotstiers:elite_terracotta_botany_pot`)
      event.hide(`botanypotstiers:ultra_terracotta_botany_pot`)
      event.hide(`botanypotstiers:creative_terracotta_botany_pot`)
    })
  })
  Color.DYE.forEach(color => {
    ['glazed_terracotta', 'nether_bricks', 'nether_12brick_stairs', 'nether_brick_slab', 'nether_brick_wall', 'shulker_box', 'banner', 'lapis_caelestis'].forEach(block => {
      event.hide(`minecraft:${color}_${block}`)
      event.hide(`miniutilities:${color}_${block}`)
    })
  })
  event.hide('#forge:ores')
  event.hide('#forge:rods')
  event.hide('#exnihilosequentia:hammer')

  event.hide('exnihilosequentia:lead_ingot')
  event.hide('exnihilosequentia:nickel_ingot')
  event.hide('exnihilosequentia:silver_ingot')
  event.hide('exnihilosequentia:tin_ingot')
  event.hide('exnihilosequentia:aluminum_ingot')
  event.hide('exnihilosequentia:platinum_ingot')
  event.hide('exnihilosequentia:uranium_ingot')
  event.hide('exnihilosequentia:zinc_ingot')
  
  event.hide('exnihilosequentia:copper_nugget')
  event.hide('exnihilosequentia:lead_nugget')
  event.hide('exnihilosequentia:nickel_nugget')
  event.hide('exnihilosequentia:silver_nugget')
  event.hide('exnihilosequentia:tin_nugget')
  event.hide('exnihilosequentia:aluminum_nugget')
  event.hide('exnihilosequentia:platinum_nugget')
  event.hide('exnihilosequentia:uranium_nugget')
  event.hide('exnihilosequentia:zinc_nugget')
  event.hide('exnihilosequentia:raw_lead')
  event.hide('exnihilosequentia:raw_nickel')
  event.hide('exnihilosequentia:raw_silver')
  event.hide('exnihilosequentia:raw_tin')
  event.hide('exnihilosequentia:raw_aluminum')
  event.hide('exnihilosequentia:raw_platinum')
  event.hide('exnihilosequentia:raw_uranium')
  event.hide('exnihilosequentia:raw_zinc')
  event.hide('exnihilothermal:obsidian_dust')

  event.hide('chickens:spawn_egg')
})


 