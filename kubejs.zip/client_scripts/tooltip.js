ItemEvents.tooltip(event => {
    event.add(['minecraft:echo_shard'], '可以通过杀死监守者掉落')
})