LootJS.modifiers((event) => {
    event
        .addEntityLootModifier("minecraft:warden")
        .addLoot("8x minecraft:echo_shard")
})