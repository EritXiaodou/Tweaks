ServerEvents.recipes(event => {
    /*event.shaped(`minecraft:warden_spawn_egg`, [
        `aaa`,
        `aba`,
        `aaa`
    ], {
        a: `minecraft:oak_log`,
        b: `minecraft:egg`
    }).id(`tamamo_the_tweaks:warden_spawn_egg`)*/
})