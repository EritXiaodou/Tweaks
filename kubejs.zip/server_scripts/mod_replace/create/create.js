ServerEvents.recipes(event => {
    event.replaceOutput({ output: 'create:copper_sheet' }, '#forge:plates/copper', '#forge:plates/copper')
    function blasting(result, input, x) {
        event.custom({
            "type": "minecraft:blasting",
            "cookingtime": 100,
            "experience": 1.0,
            "ingredient": {
                "item": "allthecompressed:" + input + "_block_" + x + "x"
            },
            "result": "allthecompressed:" + result + "_block_" + x + "x"
        })
    }
    blasting(`glass`, `sand`, 1)
    blasting(`glass`, `sand`, 2)
    blasting(`glass`, `sand`, 3)
    blasting(`glass`, `sand`, 4)
    blasting(`glass`, `sand`, 5)
    blasting(`glass`, `sand`, 6)
    blasting(`glass`, `sand`, 7)
    blasting(`glass`, `sand`, 8)
    blasting(`glass`, `sand`, 9)
    blasting(`stone`, `cobblestone`, 1)
    blasting(`stone`, `cobblestone`, 2)
    blasting(`stone`, `cobblestone`, 3)
    blasting(`stone`, `cobblestone`, 4)
    blasting(`stone`, `cobblestone`, 5)
    blasting(`stone`, `cobblestone`, 6)
    blasting(`stone`, `cobblestone`, 7)
    blasting(`stone`, `cobblestone`, 8)
    blasting(`stone`, `cobblestone`, 9)
    event.recipes.create.deploying('allthecompressed:gravel_block_1x', ['allthecompressed:cobblestone_block_1x', '#ftbsba:hammers']).damageIngredient('#ftbsba:hammers')
    event.recipes.create.deploying('allthecompressed:sand_block_1x', ['allthecompressed:gravel_block_1x', '#ftbsba:hammers']).damageIngredient('#ftbsba:hammers')
    event.recipes.create.deploying('tamamo_the_tweaks:dust_block_1x', ['allthecompressed:sand_block_1x', '#ftbsba:hammers']).damageIngredient('#ftbsba:hammers')

    event.recipes.create.filling('allthemodium:ancient_stone', ['minecraft:stone', Fluid.of('allthemodium:soul_lava')])

    event.recipes.create.haunting('allthecompressed:soul_sand_block_1x', 'allthecompressed:sand_block_1x')
    event.recipes.create.haunting('allthecompressed:soul_sand_block_2x', 'allthecompressed:sand_block_2x')
    event.recipes.create.haunting('allthecompressed:soul_sand_block_3x', 'allthecompressed:sand_block_3x')
    event.recipes.create.haunting('allthecompressed:soul_sand_block_4x', 'allthecompressed:sand_block_4x')
    event.recipes.create.haunting('allthecompressed:soul_sand_block_5x', 'allthecompressed:sand_block_5x')
    event.recipes.create.haunting('allthecompressed:soul_sand_block_6x', 'allthecompressed:sand_block_6x')
    event.recipes.create.haunting('allthecompressed:soul_sand_block_7x', 'allthecompressed:sand_block_7x')
    event.recipes.create.haunting('allthecompressed:soul_sand_block_8x', 'allthecompressed:sand_block_8x')
    event.recipes.create.haunting('allthecompressed:soul_sand_block_9x', 'allthecompressed:sand_block_9x')

    event.recipes.create.pressing(Item.of('#forge:plates/iron'), Item.of('#forge:ingots/iron'))
    event.recipes.create.pressing(Item.of('#forge:plates/gold'), Item.of('#forge:ingots/gold'))
    event.recipes.create.pressing(Item.of('#forge:plates/diamond'), Item.of('#forge:gems/diamond'))
    event.recipes.create.pressing(Item.of('#forge:plates/tin'), Item.of('#forge:ingots/tin'))
    event.recipes.create.pressing(Item.of('#forge:plates/nickel'), Item.of('#forge:ingots/nickel'))
    event.recipes.create.pressing(Item.of('#forge:plates/lead'), Item.of('#forge:ingots/lead'))
    event.recipes.create.pressing(Item.of('#forge:plates/silver'), Item.of('#forge:ingots/silver'))
    event.recipes.create.pressing(Item.of('#forge:plates/invar'), Item.of('#forge:ingots/invar'))
    event.recipes.create.pressing(Item.of('#forge:plates/constantan'), Item.of('#forge:ingots/constantan'))
    function Packing(input, result) {
        event.custom({
            "type": "create:compacting",
            "ingredients": input,
            "results": result
        })
    }
    Packing(Item.of('#forge:plates/iron', 4), 'alltheores:iron_gear')
    Packing(Item.of('#forge:plates/gold', 4), 'alltheores:gold_gear')
    Packing(Item.of('#forge:plates/copper', 4), 'alltheores:copper_gear')
    Packing(Item.of('#forge:plates/diamond', 4), 'alltheores:diamond_gear')
    Packing(Item.of('#forge:plates/tin', 4), 'alltheores:tin_gear')
    Packing(Item.of('#forge:plates/nickel', 4), 'alltheores:nickel_gear')
    Packing(Item.of('#forge:plates/lead', 4), 'alltheores:lead_gear')
    Packing(Item.of('#forge:plates/silver', 4), 'alltheores:silver_gear')
    Packing(Item.of('#forge:plates/invar', 4), 'alltheores:invar_gear')
    Packing(Item.of('#forge:plates/constantan', 4), 'alltheores:constantan_gear')
})