ServerEvents.recipes(event => {
    //等会编辑会用到的东西
    let Dirt = 'minecraft:dirt'
    let SoulSand = 'minecraft:soul_sand'
    let RedSand = 'minecraft:red_sand'
    let Gravel = 'minecraft:gravel'
    let Sand = 'minecraft:sand'
    let Dust = 'exnihilosequentia:dust'
    let Netherrack = 'exnihilosequentia:crushed_netherrack'
    let EndStone = 'exnihilosequentia:crushed_end_stone'
    let Deepslate = 'exnihilosequentia:crushed_deepslate'
    let Blackstone = 'exnihilosequentia:crushed_blackstone'
    let Moss = 'minecraft:moss_block'
    let Leaves = '#minecraft:leaves'
    let Basalt = 'exnihilosequentia:crushed_basalt'
    let Ancient_stone = 'allthemodium:ancient_stone'

    let StringMesh = 'exnihilosequentia:string_mesh'
    let FlintMesh = 'exnihilosequentia:flint_mesh'
    let IronMesh = 'exnihilosequentia:iron_mesh'
    let EmeraldMesh = 'exnihilosequentia:emerald_mesh'
    let DiamondMesh = 'exnihilosequentia:diamond_mesh'
    let NetheriteMesh = 'exnihilosequentia:netherite_mesh'
    //这个是底下All The Ores Mod自定义合成用到的不用在意
    const pieces = {
        'iron': { 'raw': 'minecraft', 'piece': 'exnihilosequentia' },
        'gold': { 'raw': 'minecraft', 'piece': 'exnihilosequentia' },
        'copper': { 'raw': 'minecraft', 'piece': 'exnihilosequentia' },
        'lead': { 'raw': 'alltheores', 'piece': 'exnihilosequentia' },
        'nickel': { 'raw': 'alltheores', 'piece': 'exnihilosequentia' },
        'silver': { 'raw': 'alltheores', 'piece': 'exnihilosequentia' },
        'tin': { 'raw': 'alltheores', 'piece': 'exnihilosequentia' },
        'platinum': { 'raw': 'alltheores', 'piece': 'exnihilosequentia' },
        'uranium': { 'raw': 'alltheores', 'piece': 'exnihilosequentia' },
        'osmium': { 'raw': 'alltheores', 'piece': 'exnihilomekanism' }
    }
    //清除mod本体添加的配方
    event.remove({ output: '#exnihilosequentia:hammer' })
    event.remove({ input: '#exnihilosequentia:hammer' })
    event.remove({ type: "exnihilosequentia:sieve", input: 'minecraft:gravel' })
    event.remove({ type: "exnihilosequentia:sieve", input: 'minecraft:sand' })
    event.remove({ type: "exnihilosequentia:sieve", input: 'exnihilosequentia:dust' })
    event.remove({ type: "exnihilosequentia:sieve", input: 'exnihilosequentia:crushed_netherrack' })
    event.remove({ type: "exnihilosequentia:sieve", input: 'exnihilosequentia:crushed_end_stone' })
    //禁用筛网合成配方
    event.remove({ id: 'exnihilosequentia:ens_flint_mesh' })
    event.remove({ id: 'exnihilosequentia:ens_iron_mesh' })
    event.remove({ id: 'exnihilosequentia:ens_golden_mesh' })
    event.remove({ id: 'exnihilosequentia:ens_diamond_mesh' })
    event.remove({ id: 'exnihilosequentia:sieve/ens_flint' })
    event.remove({ id: 'exnihilosequentia:sieve/ens_amethyst_shard' })
    event.remove({ id: `minecraft:ens_ancient_debris` })
    event.remove({ id: `/exnihilosequentia:ens_raw/` })
    //这个注释如果你还要用Ex Machinis Mod就把底下这行注释掉
    //我个人跟偏向于用Mekanism进行自动粉碎,因为All The Compressed Mod有现成的配方
    //event.remove({ id: `/exnihilosequentia:hammer/` })
    //matel
    //禁用Mod本体添加的矿物材料输入输出配方,等会方便改成All The Ores提供的矿物材料
    event.remove({ output: 'exnihilosequentia:copper_ingot' })
    event.remove({ output: 'exnihilosequentia:lead_ingot' })
    event.remove({ output: 'exnihilosequentia:nickel_ingot' })
    event.remove({ output: 'exnihilosequentia:silver_ingot' })
    event.remove({ output: 'exnihilosequentia:tin_ingot' })
    event.remove({ output: 'exnihilosequentia:aluminum_ingot' })
    event.remove({ output: 'exnihilosequentia:platinum_ingot' })
    event.remove({ output: 'exnihilosequentia:uranium_ingot' })
    event.remove({ output: 'exnihilosequentia:zinc_ingot' })
    event.remove({ input: 'exnihilosequentia:lead_ingot' })
    event.remove({ input: 'exnihilosequentia:nickel_ingot' })
    event.remove({ input: 'exnihilosequentia:silver_ingot' })
    event.remove({ input: 'exnihilosequentia:tin_ingot' })
    event.remove({ input: 'exnihilosequentia:aluminum_ingot' })
    event.remove({ input: 'exnihilosequentia:platinum_ingot' })
    event.remove({ input: 'exnihilosequentia:uranium_ingot' })
    event.remove({ input: 'exnihilosequentia:zinc_ingot' })

    event.remove({ output: 'exnihilosequentia:copper_nugget' })
    event.remove({ output: 'exnihilosequentia:lead_nugget' })
    event.remove({ output: 'exnihilosequentia:nickel_nugget' })
    event.remove({ output: 'exnihilosequentia:silver_nugget' })
    event.remove({ output: 'exnihilosequentia:tin_nugget' })
    event.remove({ output: 'exnihilosequentia:aluminum_nugget' })
    event.remove({ output: 'exnihilosequentia:platinum_nugget' })
    event.remove({ output: 'exnihilosequentia:uranium_nugget' })
    event.remove({ output: 'exnihilosequentia:zinc_nugget' })
    event.remove({ input: 'exnihilosequentia:lead_nugget' })
    event.remove({ input: 'exnihilosequentia:nickel_nugget' })
    event.remove({ input: 'exnihilosequentia:silver_nugget' })
    event.remove({ input: 'exnihilosequentia:tin_nugget' })
    event.remove({ input: 'exnihilosequentia:aluminum_nugget' })
    event.remove({ input: 'exnihilosequentia:platinum_nugget' })
    event.remove({ input: 'exnihilosequentia:uranium_nugget' })
    event.remove({ input: 'exnihilosequentia:zinc_nugget' })

    event.remove({ id: 'exnihilomekanism:ens_raw_osmium' })
    event.remove({ id: 'exnihilomekanism:ens_osmium_pieces' })
    event.remove({ id: `exnihiloae:sieve/ens_certus_seed` })
    event.shapeless(Gravel, [Item.of('ftbsba:stone_hammer'), 'minecraft:cobblestone']).damageIngredient(Item.of('ftbsba:stone_hammer'), 1).keepIngredient('ftbsba:stone_hammer')
	event.shapeless(Sand, [Item.of('ftbsba:stone_hammer'), Gravel]).damageIngredient(Item.of('ftbsba:stone_hammer'), 1).keepIngredient('ftbsba:stone_hammer')
	event.shapeless(Dust, [Item.of('ftbsba:stone_hammer'), Sand]).damageIngredient(Item.of('ftbsba:stone_hammer'), 1).keepIngredient('ftbsba:stone_hammer')
    event.shapeless(Gravel, [Item.of('ftbsba:iron_hammer'), 'minecraft:cobblestone']).damageIngredient(Item.of('ftbsba:iron_hammer'), 1).keepIngredient('ftbsba:iron_hammer')
	event.shapeless(Sand, [Item.of('ftbsba:iron_hammer'), Gravel]).damageIngredient(Item.of('ftbsba:iron_hammer'), 1).keepIngredient('ftbsba:iron_hammer')
	event.shapeless(Dust, [Item.of('ftbsba:iron_hammer'), Sand]).damageIngredient(Item.of('ftbsba:iron_hammer'), 1).keepIngredient('ftbsba:iron_hammer')
    event.shapeless(Gravel, [Item.of('ftbsba:gold_hammer'), 'minecraft:cobblestone']).damageIngredient(Item.of('ftbsba:gold_hammer'), 1).keepIngredient('ftbsba:gold_hammer')
	event.shapeless(Sand, [Item.of('ftbsba:gold_hammer'), Gravel]).damageIngredient(Item.of('ftbsba:gold_hammer'), 1).keepIngredient('ftbsba:gold_hammer')
	event.shapeless(Dust, [Item.of('ftbsba:gold_hammer'), Sand]).damageIngredient(Item.of('ftbsba:gold_hammer'), 1).keepIngredient('ftbsba:gold_hammer')
    event.shapeless(Gravel, [Item.of('ftbsba:diamond_hammer'), 'minecraft:cobblestone']).damageIngredient(Item.of('ftbsba:diamond_hammer'), 1).keepIngredient('ftbsba:diamond_hammer')
	event.shapeless(Sand, [Item.of('ftbsba:diamond_hammer'), Gravel]).damageIngredient(Item.of('ftbsba:diamond_hammer'), 1).keepIngredient('ftbsba:diamond_hammer')
	event.shapeless(Dust, [Item.of('ftbsba:diamond_hammer'), Sand]).damageIngredient(Item.of('ftbsba:diamond_hammer'), 1).keepIngredient('ftbsba:diamond_hammer')
    event.shapeless(Gravel, [Item.of('ftbsba:netherite_hammer'), 'minecraft:cobblestone']).damageIngredient(Item.of('ftbsba:netherite_hammer'), 1).keepIngredient('ftbsba:netherite_hammer')
	event.shapeless(Sand, [Item.of('ftbsba:netherite_hammer'), Gravel]).damageIngredient(Item.of('ftbsba:netherite_hammer'), 1).keepIngredient('ftbsba:netherite_hammer')
	event.shapeless(Dust, [Item.of('ftbsba:netherite_hammer'), Sand]).damageIngredient(Item.of('ftbsba:netherite_hammer'), 1).keepIngredient('ftbsba:netherite_hammer')
    //筛网升级-锻造台
    event.smithing(FlintMesh, StringMesh, 'minecraft:flint')
    event.smithing(IronMesh, FlintMesh, 'minecraft:iron_ingot')
    event.smithing(DiamondMesh, IronMesh, 'minecraft:diamond')
    event.smithing(EmeraldMesh, DiamondMesh, 'minecraft:emerald')
    event.smithing(NetheriteMesh, EmeraldMesh, 'minecraft:netherite_ingot')
    //替换黑曜石粉末输入
    event.replaceInput({ id: 'exnihilothermal:ens_basalz_doll' }, '#forge:dust/obsidian', '#forge:dusts/obsidian')
    //不含水筛网配方模板
    function sieve(mesh, chance, input, result) {
        event.custom({
            "type": `exnihilosequentia:sieve`,
            "rolls": [{
                "chance": chance,
                "mesh": mesh
            }],
            "input": input,
            "result": result
        })
    }
    //筛网配方
    //sieve(筛网等级, 概率, 输入的材料, 输出的材料)
    //Mud
    sieve(`netherite`, 0.001, `minecraft:mud`, 'minecraft:echo_shard')
    //Gravel
    sieve(`string`, 0.5, Gravel, 'minecraft:flint')
    sieve(`flint`, 0.25, Gravel, 'minecraft:flint')
    sieve(`flint`, 0.125, Gravel, 'minecraft:lapis_lazuli')
    sieve(`iron`, 0.15, Gravel, 'minecraft:lapis_lazuli')
    sieve(`flint`, 0.125, Gravel, 'minecraft:coal')
    sieve(`iron`, 0.15, Gravel, 'minecraft:coal')
    sieve(`flint`, 0.075, Gravel, 'exnihilosequentia:copper_pieces')
    sieve(`iron`, 0.1, Gravel, 'exnihilosequentia:copper_pieces')
    sieve(`diamond`, 0.125, Gravel, 'exnihilosequentia:copper_pieces')
    sieve(`emerald`, 0.15, Gravel, 'exnihilosequentia:copper_pieces')
    sieve(`netherite`, 0.175, Gravel, 'exnihilosequentia:copper_pieces')
    sieve(`flint`, 0.075, Gravel, 'exnihilosequentia:iron_pieces')
    sieve(`iron`, 0.1, Gravel, 'exnihilosequentia:iron_pieces')
    sieve(`diamond`, 0.125, Gravel, 'exnihilosequentia:iron_pieces')
    sieve(`emerald`, 0.15, Gravel, 'exnihilosequentia:iron_pieces')
    sieve(`netherite`, 0.175, Gravel, 'exnihilosequentia:iron_pieces')
    sieve(`diamond`, 0.1, Gravel, 'exnihilosequentia:gold_pieces')
    sieve(`emerald`, 0.125, Gravel, 'exnihilosequentia:gold_pieces')
    sieve(`netherite`, 0.15, Gravel, 'exnihilosequentia:gold_pieces')
    sieve(`iron`, 0.005, Gravel, 'minecraft:diamond')
    sieve(`diamond`, 0.0075, Gravel, 'minecraft:diamond')
    sieve(`emerald`, 0.01, Gravel, 'minecraft:diamond')
    sieve(`netherite`, 0.0125, Gravel, 'minecraft:diamond')
    sieve(`iron`, 0.005, Gravel, 'minecraft:emerald')
    sieve(`diamond`, 0.0075, Gravel, 'minecraft:emerald')
    sieve(`emerald`, 0.01, Gravel, 'minecraft:emerald')
    sieve(`netherite`, 0.0125, Gravel, 'minecraft:emerald')
    sieve(`iron`, 0.03, Gravel, 'exnihilosequentia:lead_pieces')
    sieve(`diamond`, 0.06, Gravel, 'exnihilosequentia:lead_pieces')
    sieve(`emerald`, 0.09, Gravel, 'exnihilosequentia:lead_pieces')
    sieve(`netherite`, 0.12, Gravel, 'exnihilosequentia:lead_pieces')
    sieve(`iron`, 0.03, Gravel, 'exnihilosequentia:nickel_pieces')
    sieve(`diamond`, 0.06, Gravel, 'exnihilosequentia:nickel_pieces')
    sieve(`emerald`, 0.09, Gravel, 'exnihilosequentia:nickel_pieces')
    sieve(`netherite`, 0.12, Gravel, 'exnihilosequentia:nickel_pieces')
    sieve(`iron`, 0.03, Gravel, 'exnihilosequentia:tin_pieces')
    sieve(`diamond`, 0.06, Gravel, 'exnihilosequentia:tin_pieces')
    sieve(`emerald`, 0.09, Gravel, 'exnihilosequentia:tin_pieces')
    sieve(`netherite`, 0.12, Gravel, 'exnihilosequentia:tin_pieces')
    //Netherrack
    sieve(`diamond`, 0.04, Netherrack, 'minecraft:netherite_scrap')
    sieve(`emerald`, 0.08, Netherrack, 'minecraft:netherite_scrap')
    sieve(`netherite`, 0.16, Netherrack, 'minecraft:netherite_scrap')
    sieve(`diamond`, 0.15, Netherrack, 'exnihilosequentia:gold_pieces')
    sieve(`emerald`, 0.20, Netherrack, 'exnihilosequentia:gold_pieces')
    sieve(`netherite`, 0.25, Netherrack, 'exnihilosequentia:gold_pieces')
    sieve(`iron`, 0.20, Netherrack, `minecraft:quartz`)
    sieve(`diamond`, 0.25, Netherrack, `minecraft:quartz`)
    sieve(`emerald`, 0.30, Netherrack, `minecraft:quartz`)
    sieve(`netherite`, 0.35, Netherrack, `minecraft:quartz`)
    //Sand
    sieve(`iron`, 0.20, Sand, `thermal:sulfur`)
    sieve(`diamond`, 0.25, Sand, `thermal:sulfur`)
    sieve(`emerald`, 0.30, Sand, `thermal:sulfur`)
    sieve(`netherite`, 0.35, Sand, `thermal:sulfur`)
    sieve(`iron`, 0.20, Sand, `thermal:apatite`)
    sieve(`diamond`, 0.25, Sand, `thermal:apatite`)
    sieve(`emerald`, 0.30, Sand, `thermal:apatite`)
    sieve(`netherite`, 0.35, Sand, `thermal:apatite`)
    sieve(`iron`, 0.20, Sand, `thermal:cinnabar`)
    sieve(`diamond`, 0.25, Sand, `thermal:cinnabar`)
    sieve(`emerald`, 0.30, Sand, `thermal:cinnabar`)
    sieve(`netherite`, 0.35, Sand, `thermal:cinnabar`)
    sieve(`iron`, 0.20, Sand, `mekanism:salt`)
    sieve(`diamond`, 0.25, Sand, `mekanism:salt`)
    sieve(`emerald`, 0.30, Sand, `mekanism:salt`)
    sieve(`netherite`, 0.35, Sand, `mekanism:salt`)
    sieve(`iron`, 0.03, Sand, `exnihilosequentia:uranium_pieces`)
    sieve(`diamond`, 0.06, Sand, `exnihilosequentia:uranium_pieces`)
    sieve(`emerald`, 0.09, Sand, `exnihilosequentia:uranium_pieces`)
    sieve(`netherite`, 0.12, Sand, `exnihilosequentia:uranium_pieces`)
    //Redsand
    sieve(`iron`, 0.20, RedSand, `thermal:sulfur`)
    sieve(`diamond`, 0.25, RedSand, `thermal:sulfur`)
    sieve(`emerald`, 0.30, RedSand, `thermal:sulfur`)
    sieve(`netherite`, 0.35, RedSand, `thermal:sulfur`)
    sieve(`iron`, 0.20, RedSand, `thermal:apatite`)
    sieve(`diamond`, 0.25, RedSand, `thermal:apatite`)
    sieve(`emerald`, 0.30, RedSand, `thermal:apatite`)
    sieve(`netherite`, 0.35, RedSand, `thermal:apatite`)
    sieve(`iron`, 0.20, RedSand, `thermal:cinnabar`)
    sieve(`diamond`, 0.25, RedSand, `thermal:cinnabar`)
    sieve(`emerald`, 0.30, RedSand, `thermal:cinnabar`)
    sieve(`netherite`, 0.35, RedSand, `thermal:cinnabar`)
    sieve(`iron`, 0.20, RedSand, `mekanism:salt`)
    sieve(`diamond`, 0.25, RedSand, `mekanism:salt`)
    sieve(`emerald`, 0.30, RedSand, `mekanism:salt`)
    sieve(`netherite`, 0.35, RedSand, `mekanism:salt`)
    sieve(`iron`, 0.03, RedSand, `exnihilosequentia:uranium_pieces`)
    sieve(`diamond`, 0.06, RedSand, `exnihilosequentia:uranium_pieces`)
    sieve(`emerald`, 0.09, RedSand, `exnihilosequentia:uranium_pieces`)
    sieve(`netherite`, 0.12, RedSand, `exnihilosequentia:uranium_pieces`)
    sieve(`diamond`, 0.06, RedSand, `2x minecraft:gold_nugget`)
    sieve(`emerald`, 0.09, RedSand, `2x minecraft:gold_nugget`)
    sieve(`netherite`, 0.12, RedSand, `2x minecraft:gold_nugget`)
    //Dust
    sieve(`iron`, 0.125, Dust, `minecraft:redstone`)
    sieve(`diamond`, 0.15, Dust, `minecraft:redstone`)
    sieve(`emerald`, 0.175, Dust, `minecraft:redstone`)
    sieve(`netherite`, 0.2, Dust, `minecraft:redstone`)
    sieve(`iron`, 0.03, Dust, `minecraft:bone_meal`)
    sieve(`diamond`, 0.06, Dust, `minecraft:bone_meal`)
    sieve(`emerald`, 0.09, Dust, `minecraft:bone_meal`)
    sieve(`netherite`, 0.12, Dust, `minecraft:bone_meal`)
    sieve(`iron`, 0.20, Dust, `mekanism:fluorite_gem`)
    sieve(`diamond`, 0.25, Dust, `mekanism:fluorite_gem`)
    sieve(`emerald`, 0.30, Dust, `mekanism:fluorite_gem`)
    sieve(`netherite`, 0.35, Dust, `mekanism:fluorite_gem`)
    sieve(`iron`, 0.03, Dust, `exnihilosequentia:silver_pieces`)
    sieve(`diamond`, 0.06, Dust, `exnihilosequentia:silver_pieces`)
    sieve(`emerald`, 0.09, Dust, `exnihilosequentia:silver_pieces`)
    sieve(`netherite`, 0.12, Dust, `exnihilosequentia:silver_pieces`)
    sieve(`iron`, 0.03, Dust, `exnihilomekanism:osmium_pieces`)
    sieve(`diamond`, 0.06, Dust, `exnihilomekanism:osmium_pieces`)
    sieve(`emerald`, 0.09, Dust, `exnihilomekanism:osmium_pieces`)
    sieve(`netherite`, 0.12, Dust, `exnihilomekanism:osmium_pieces`)
    //Leaves
    sieve(`iron`, 0.1, Leaves, `integrateddynamics:menril_sapling`)
    sieve(`diamond`, 0.15, Leaves, `integrateddynamics:menril_sapling`)
    sieve(`emerald`, 0.2, Leaves, `integrateddynamics:menril_sapling`)
    //Blackstone
    sieve(`iron`, 0.5, Blackstone, `7x minecraft:gold_nugget`)
    sieve(`diamond`, 0.5, Blackstone, `7x minecraft:gold_nugget`)
    sieve(`emerald`, 0.5, Blackstone, `8x minecraft:gold_nugget`)
    sieve(`netherite`, 0.5, Blackstone, `9x minecraft:gold_nugget`)
    sieve(`netherite`, 0.015, Blackstone, `allthemodium:vibranium_shard`)
    //Endstone
    sieve(`iron`, 0.03, EndStone, `exnihilosequentia:platinum_pieces`)
    sieve(`diamond`, 0.06, EndStone, `exnihilosequentia:platinum_pieces`)
    sieve(`emerald`, 0.09, EndStone, `exnihilosequentia:platinum_pieces`)
    sieve(`netherite`, 0.12, EndStone, `exnihilosequentia:platinum_pieces`)
    sieve(`netherite`, 0.015, EndStone, `allthemodium:allthemodium_shard`)
    sieve(`emerald`, 0.10, EndStone, `minecraft:ender_pearl`)
    sieve(`netherite`, 0.15, EndStone, `minecraft:ender_pearl`)
    //soulsand
    sieve(`string`, 0.15, SoulSand, `allthemodium:ancient_soulberries`)
    sieve(`flint`, 0.15, SoulSand, `miniutilities:flame_lily`)
    sieve(`iron`, 0.10, SoulSand, `minecraft:glowstone_dust`)
    sieve(`diamond`, 0.12, SoulSand, `minecraft:glowstone_dust`)
    sieve(`emerald`, 0.14, SoulSand, `minecraft:glowstone_dust`)
    sieve(`netherite`, 0.16, SoulSand, `minecraft:glowstone_dust`)
    sieve(`emerald`, 0.04, SoulSand, `minecraft:ghast_tear`)
    //basalt
    sieve(`emerald`, 0.1, Basalt, `minecraft:amethyst_shard`)
    sieve(`netherite`, 0.2, Basalt, `minecraft:amethyst_shard`)
    //ancient_stone
    sieve(`netherite`, 0.002, Ancient_stone, `allthemodium:allthemodium_shard`)
    sieve(`netherite`, 0.002, Ancient_stone, `allthemodium:vibranium_shard`)

    //含水筛网配方模板
    function WaterSieve(mesh, chance, input, result) {
        event.custom({
            type: `exnihilosequentia:sieve`,
            rolls: [{
                chance: chance,
                mesh: mesh
            }],
            input: input,
            result: result,
            waterlogged: true
        })
    }
    //与顶上同理
    //Moss
    WaterSieve(`string`, 0.2, Moss, 'thermal:rubberwood_sapling')
    WaterSieve(`string`, 0.2, Moss, 'minecraft:cactus')
    WaterSieve(`string`, 0.2, Moss, 'minecraft:sugar_cane')
    //Sand
    WaterSieve(`flint`, 0.1, Sand, 'minecraft:scute')
    WaterSieve(`iron`, 0.2, Sand, 'minecraft:scute')
    //Redsand
    WaterSieve(`flint`, 0.1, RedSand, 'minecraft:scute')
    WaterSieve(`iron`, 0.2, RedSand, 'minecraft:scute')
    //Endstone
    WaterSieve(`iron`, 0.10, EndStone, `minecraft:chorus_flower`)
    WaterSieve(`diamond`, 0.20, EndStone, `minecraft:chorus_flower`)
    WaterSieve(`emerald`, 0.30, EndStone, `minecraft:chorus_flower`)
    WaterSieve(`netherite`, 0.40, EndStone, `minecraft:chorus_flower`)
    //dirt
    WaterSieve(`string`, 0.15, Dirt, `minecraft:sugar_cane`)
    //坩埚热源等级
    function heat(block, heat) {
        event.custom({ type: `exnihilosequentia:heat`, block: block, amount: heat })
    }
    //heat(方块, 倍率)
    heat(`thermal:crude_oil_fluid`, 8)
    heat(`alltheores:uranium_block`, 20)
    heat(`miniutilities:unstable_block`, 100)
    //未编辑区域
    //粉碎输出多份材料
    function hammersss(input, output, count) {
        event.custom({ type: `exnihilosequentia:hammer`, input: Item.of(input).toJson(), results: [Item.of(output).withCount(count).toResultJson()] })
    }
    //粉碎
    function hammer(input, output) {
        event.custom({ type: `exnihilosequentia:hammer`, input: Item.of(input).toJson(), results: [Item.of(output).toResultJson()] })
    }
    //桶
    function fluidItem(fluid, input, output) {
        event.custom({ type: `exnihilosequentia:fluid_item`, fluid: Fluid.of(fluid), input: Ingredient.of(input), result: Item.of(output) })
    }
    //Mekanism、Thermal、IE、ID等Mod粉碎配方
    function crushEm(result, crush) {
        event.recipes.mekanism.crushing(Item.of(result), crush)
        event.recipes.thermal.pulverizer(Item.of(result), crush)
        event.recipes.immersiveengineering.crusher(Item.of(result), crush)
        event.custom({
            type: `integrateddynamics:squeezer`,
            item: Ingredient.of(crush).toJson(),
            result: {
                items: [Item.of(result).toResultJson()]
            }
        })
        event.custom({
            type: `integrateddynamics:mechanical_squeezer`,
            item: Ingredient.of(crush).toJson(),
            result: {
                items: [Item.of(result).toResultJson()]
            },
            duration: 40
        })
    }
    //All The ores 材料碎片合成
    Object.entries(pieces).forEach(([name, mods]) => {
        //2x2 Table Crafting
        event.shaped(`${mods.raw}:raw_${name}`, [
            'aa',
            'aa'
        ],
            { a: `${mods.piece}:${name}_pieces` }).id(`tamamo_the_tweaks:raw_${name}_from_piece`)
        //Press Raw ores
        //Thermal Press
        if (Platform.isLoaded('thermal_expansion')) {
            event.custom({
                'type': 'thermal:press',
                'ingredients': [
                    { 'item': `${mods.piece}:${name}_pieces`, 'count': 4 },
                    { 'item': 'thermal:press_packing_2x2_die' }
                ],
                'result': [{ 'item': `${mods.raw}:raw_${name}` }],
                'energy': 400
            }).id(`tamamo_the_tweaks:thermal/press/raw_${name}_from_piece`)
        }
        //Create Press
        //动力辊压机还没写
    })
    event.shaped(`exmachinis:gold_upgrade`, [
        `aaa`,
        `bcb`,
        `bdb`
    ], {
        a: `minecraft:polished_deepslate`,
        b: `minecraft:iron_bars`,
        c: `minecraft:gold_block`,
        d: `minecraft:hopper`
    }).id(`exmachinis:gold_upgrade`)
})