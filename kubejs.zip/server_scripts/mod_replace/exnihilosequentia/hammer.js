BlockEvents.rightClicked(event => {
    const hammer = {
        'iron': { 'mod': 'exnihilosequentia', 'id': 'exnihilosequentia' },
        'golden': { 'mod': 'exnihilosequentia', 'id': 'exnihilosequentia' },
        'diamond': { 'mod': 'exnihilosequentia', 'id': 'exnihilosequentia' },
        'netherite': { 'mod': 'exnihilosequentia', 'id': 'exnihilosequentia' }
    }
    Object.entries(hammer).forEach(([name, mods]) => {
        let cobblestone = "minecraft:cobblestone"
        let gravel = "minecraft:gravel"
        let sand = "minecraft:sand"
        let dust = "exnihilosequentia:dust"
        const { hand, player } = event
        if (hand != 'MAIN_HAND') return
        if (!player.isShiftKeyDown()) return
        if (event.item == `${mods.mod}:${name}_hammer`) {
            if (event.block == cobblestone) {
                event.server.runCommandSilent(`setblock ${event.getBlock().getX()} ${event.getBlock().getY()} ${event.getBlock().getZ()} ${gravel}`)
            }
            if (event.block == gravel) {
                event.server.runCommandSilent(`setblock ${event.getBlock().getX()} ${event.getBlock().getY()} ${event.getBlock().getZ()} ${sand}`)
            }
            if (event.block == sand) {
                event.server.runCommandSilent(`setblock ${event.getBlock().getX()} ${event.getBlock().getY()} ${event.getBlock().getZ()} ${dust}`)
            }
            player.swing()
        }
    })
})