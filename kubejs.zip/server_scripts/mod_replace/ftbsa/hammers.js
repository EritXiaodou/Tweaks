ServerEvents.recipes(event => {
    const ftbtools = event.recipes.ftbsba
    ftbtools.hammer([Item.of("allthecompressed:cobblestone_block_1x")], "#forge:cobbled_block").id('tamamo_the_tweaks:hammer/cobbled_block_to_cobblestone')
    ftbtools.hammer([Item.of("allthecompressed:gravel_block_1x")], "#forge:graveld_block").id('tamamo_the_tweaks:hammer/graveld_block_to_gravel')
    ftbtools.hammer([Item.of("allthecompressed:sand_block_1x")], "#forge:sanded_block").id('tamamo_the_tweaks:hammer/gravel_block_to_sand')
    ftbtools.hammer([Item.of("tamamo_the_tweaks:dust_block_1x")], "#forge:storage_blocks/red_sand").id('tamamo_the_tweaks:hammer/sand_block_to_dust')
    ftbtools.hammer([Item.of("tamamo_the_tweaks:dust_block_1x")], "#forge:storage_blocks/sand").id('tamamo_the_tweaks:hammer/red_sand_block_to_dust')

    ftbtools.hammer([Item.of(`exnihilosequentia:crushed_netherrack`)], 'minecraft:netherrack').id('tamamo_the_tweaks:hammer/crushed_netherrack')
    ftbtools.hammer([Item.of(`exnihilosequentia:crushed_end_stone`)], 'minecraft:end_stone').id('tamamo_the_tweaks:hammer/crushed_end_stone')
    ftbtools.hammer([Item.of(`exnihilosequentia:crushed_basalt`)], 'minecraft:basalt').id('tamamo_the_tweaks:hammer/crushed_basalt')
    ftbtools.hammer([Item.of(`exnihilosequentia:crushed_blackstone`)], 'minecraft:blackstone').id('tamamo_the_tweaks:hammer/crushed_blackstone')

    ftbtools.hammer([Item.of(`exnihilosequentia:crushed_netherrack`, 9)], "allthecompressed:netherrack_block_1x").id('tamamo_the_tweaks:hammer/crushed_netherrack_1x')
    ftbtools.hammer([Item.of(`exnihilosequentia:crushed_end_stone`, 9)], "allthecompressed:end_stone_block_1x").id('tamamo_the_tweaks:hammer/crushed_end_stone_1x')
    ftbtools.hammer([Item.of(`exnihilosequentia:crushed_basalt`, 9)], '#forge:storage_blocks/basalt').id('tamamo_the_tweaks:hammer/crushed_basalt_1x')
    ftbtools.hammer([Item.of(`exnihilosequentia:crushed_blackstone`, 9)], "allthecompressed:blackstone_block_1x").id('tamamo_the_tweaks:hammer/crushed_blackstone_block_1x')

    ftbtools.hammer([Item.of(`thermal:sawdust`, 5)], '#minecraft:logs').id('tamamo_the_tweaks:hammer/sawdust')

})