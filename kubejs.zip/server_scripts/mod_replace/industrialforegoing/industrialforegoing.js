ServerEvents.recipes(event => {
    event.remove({ type: `industrialforegoing:laser_drill_ore` })
    event.remove({ id: 'industrialforegoing:dissolution_chamber/efficiency_addon_2' })
    event.remove({ id: 'industrialforegoing:dissolution_chamber/speed_addon_2' })
    event.remove({ id: 'industrialforegoing:dissolution_chamber/processing_addon_2' })
    event.replaceInput({ output: 'industrialforegoing:pitiful_generator' }, 'minecraft:iron_bars', '#forge:ingots/iron')
    event.custom({
        "type": "industrialforegoing:laser_drill_fluid",
        "catalyst": {
            "item": "industrialforegoing:laser_lens15"
        },
        "entity": "minecraft:warden",
        "output": "{Amount:1,FluidName:\"kubejs:echo_essence\"}",
        "pointer": 0,
        "rarity": [
            {
                "blacklist": {},
                "depth_max": -32,
                "depth_min": -64,
                "weight": 8,
                "whitelist": {}
            }
        ]
    }).id('echo_essence')
    event.recipes.industrialforegoing.fluid_extractor(
        "thermal:rubberwood_log",
        "thermal:stripped_rubberwood_log",
        0.5,
        Fluid.of('thermal:latex', 50)
    )
    event.recipes.industrialforegoing.dissolution_chamber(
        [
            "tamamo_the_tweaks:alloy_infinite",
            "tamamo_the_tweaks:cosmic_upgrade_augment",
            "tamamo_the_tweaks:alloy_infinite",
            "createaddition:large_connector",
            "createaddition:large_connector",
            "tamamo_the_tweaks:alloy_infinite",
            "tamamo_the_tweaks:infinite_upgrade",
            "tamamo_the_tweaks:alloy_infinite"
        ],
        Fluid.of(`kubejs:cryotheum`, 2000),
        "tamamo_the_tweaks:infinite_upgrade_augment",
        100 // time
    )
})