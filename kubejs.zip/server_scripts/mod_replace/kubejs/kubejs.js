ServerEvents.recipes(event => {
    event.shaped('4x minecraft:chest', [
        "AAA",
        "A A",
        "AAA"
    ], { A: '#minecraft:logs' }).id('tamamo_the_tweaks:chest')
    event.shaped('tamamo_the_tweaks:compressed_core', [
        "ACA",
        "ABA",
        "AAA"
    ], { A: 'compactmachines:wall', B: 'minecraft:nether_star', C: 'minecraft:ender_pearl' }).id('tamamo_the_tweaks:compressed_core')
    event.shaped('minecraft:cobblestone', [
        "A",
        "A"
    ], { A: 'minecraft:cobblestone_slab' }).id('tamamo_the_tweaks:cobblestone')
    function IngotToNugget(materials) {
        event.shaped(Item.of('#forge:nuggets/' + materials, 9), [
            'A'
        ],
            {
                A: '#forge:ingots/' + materials
            }
        ).id(`tamamo_the_tweaks:` + materials + `_ingot_to_nugget`)
    }
    IngotToNugget('tin')
    IngotToNugget('silver')
    IngotToNugget('nickel')
    IngotToNugget('lead')
    IngotToNugget('uranium')
    function NuggetToIngot(materials) {
        event.shaped(Item.of('#forge:ingots/' + materials, 9), [
            'AAA',
            'AAA',
            'AAA'
        ],
            {
                A: '#forge:nuggets/' + materials
            }
        ).id(`tamamo_the_tweaks:` + materials + `__to_ingot`)
    }
    NuggetToIngot('tin')
    NuggetToIngot('silver')
    NuggetToIngot('nickel')
    NuggetToIngot('lead')
    NuggetToIngot('uranium')
    
    event.smelting('3x minecraft:bread', 'minecraft:hay_block').xp(0.35)
    function shapedBlock(result, input, id) {
        event.shaped(result, [
            'aaa',
            'aaa',
            'aaa'
        ],
            { a: input }
        ).id(id)
    }
    shapedBlock(`alltheores:lead_block`, `alltheores:lead_ingot`, `tamamo_the_tweaks:block_lead_from_ingot`)
    shapedBlock(`alltheores:nickel_block`, `alltheores:nickel_ingot`, `tamamo_the_tweaks:block_nickel_from_ingot`)
    shapedBlock(`alltheores:silver_block`, `alltheores:silver_ingot`, `tamamo_the_tweaks:block_silver_from_ingot`)
    shapedBlock(`alltheores:tin_block`, `alltheores:tin_ingot`, `tamamo_the_tweaks:block_tin_from_ingot`)
    shapedBlock(`alltheores:platinum_block`, `alltheores:platinum_ingot`, `tamamo_the_tweaks:block_platinum_from_ingot`)
    shapedBlock(`alltheores:uranium_block`, `alltheores:uranium_ingot`, `tamamo_the_tweaks:block_uranium_from_ingot`)
    shapedBlock(`alltheores:osmium_block`, `alltheores:osmium_ingot`, `tamamo_the_tweaks:block_osmium_from_ingot`)
    shapedBlock(`tamamo_the_tweaks:dust_block_1x`, `exnihilosequentia:dust`, `tamamo_the_tweaks:dust_block_1x`)
    shapedBlock(`tamamo_the_tweaks:blaze_rod_block`, 'minecraft:blaze_rod', `tamamo_the_tweaks:blaze_rod_block`)
    shapedBlock(`allthecompressed:blaze_rod_block_1x`, `#forge:storage_blocks/blaze`, `allthecompressed:blaze_rod_block`)

    event.shapeless(Item.of('exnihilosequentia:dust', 9), 'tamamo_the_tweaks:dust_block_1x').id('tamamo_the_tweaks:dust')
    function shapedCompressed(result, materials, id) {
        event.shaped(result, [
            'aaa',
            'aaa',
            'aaa'
        ],
            { a: materials }
        ).id(id)
    }
    shapedCompressed(`#forge:ingots/silver`, `#forge:nuggets/silver`, `tamamo_the_tweaks:silver_nugget_to_ingot`)
    shapedCompressed(`tamamo_the_tweaks:raw_netherite_scrap_block`, `minecraft:netherite_scrap`, `tamamo_the_tweaks:raw_netherite_block`)
    shapedCompressed(`tamamo_the_tweaks:dust_block_2x`, `tamamo_the_tweaks:dust_block_1x`, `tamamo_the_tweaks:dust_block_2x`)

    shapedCompressed(`tamamo_the_tweaks:crushed_netherrack_block_1x`, `exnihilosequentia:crushed_netherrack`, `tamamo_the_tweaks:crushed_netherrack_block_1x`)
    shapedCompressed(`tamamo_the_tweaks:crushed_netherrack_block_2x`, `tamamo_the_tweaks:crushed_netherrack_block_1x`, `tamamo_the_tweaks:crushed_netherrack_block_2x`)
    shapedCompressed(`tamamo_the_tweaks:crushed_netherrack_block_3x`, `tamamo_the_tweaks:crushed_netherrack_block_2x`, `tamamo_the_tweaks:crushed_netherrack_block_3x`)
    shapedCompressed(`tamamo_the_tweaks:crushed_netherrack_block_4x`, `tamamo_the_tweaks:crushed_netherrack_block_3x`, `tamamo_the_tweaks:crushed_netherrack_block_4x`)
    shapedCompressed(`tamamo_the_tweaks:crushed_netherrack_block_5x`, `tamamo_the_tweaks:crushed_netherrack_block_4x`, `tamamo_the_tweaks:crushed_netherrack_block_5x`)
    shapedCompressed(`tamamo_the_tweaks:crushed_netherrack_block_6x`, `tamamo_the_tweaks:crushed_netherrack_block_5x`, `tamamo_the_tweaks:crushed_netherrack_block_6x`)
    shapedCompressed(`tamamo_the_tweaks:crushed_netherrack_block_7x`, `tamamo_the_tweaks:crushed_netherrack_block_6x`, `tamamo_the_tweaks:crushed_netherrack_block_7x`)
    shapedCompressed(`tamamo_the_tweaks:crushed_netherrack_block_8x`, `tamamo_the_tweaks:crushed_netherrack_block_7x`, `tamamo_the_tweaks:crushed_netherrack_block_8x`)
    shapedCompressed(`tamamo_the_tweaks:crushed_netherrack_block_9x`, `tamamo_the_tweaks:crushed_netherrack_block_8x`, `tamamo_the_tweaks:crushed_netherrack_block_9x`)

    shapedCompressed(`tamamo_the_tweaks:crushed_blackstone_block_1x`, `exnihilosequentia:crushed_blackstone`, `tamamo_the_tweaks:crushed_blackstone_block_1x`)
    shapedCompressed(`tamamo_the_tweaks:crushed_blackstone_block_2x`, `tamamo_the_tweaks:crushed_blackstone_block_1x`, `tamamo_the_tweaks:crushed_blackstone_block_2x`)
    shapedCompressed(`tamamo_the_tweaks:crushed_blackstone_block_3x`, `tamamo_the_tweaks:crushed_blackstone_block_2x`, `tamamo_the_tweaks:crushed_blackstone_block_3x`)
    shapedCompressed(`tamamo_the_tweaks:crushed_blackstone_block_4x`, `tamamo_the_tweaks:crushed_blackstone_block_3x`, `tamamo_the_tweaks:crushed_blackstone_block_4x`)
    shapedCompressed(`tamamo_the_tweaks:crushed_blackstone_block_5x`, `tamamo_the_tweaks:crushed_blackstone_block_4x`, `tamamo_the_tweaks:crushed_blackstone_block_5x`)
    shapedCompressed(`tamamo_the_tweaks:crushed_blackstone_block_6x`, `tamamo_the_tweaks:crushed_blackstone_block_5x`, `tamamo_the_tweaks:crushed_blackstone_block_6x`)
    shapedCompressed(`tamamo_the_tweaks:crushed_blackstone_block_7x`, `tamamo_the_tweaks:crushed_blackstone_block_6x`, `tamamo_the_tweaks:crushed_blackstone_block_7x`)
    shapedCompressed(`tamamo_the_tweaks:crushed_blackstone_block_8x`, `tamamo_the_tweaks:crushed_blackstone_block_7x`, `tamamo_the_tweaks:crushed_blackstone_block_8x`)
    shapedCompressed(`tamamo_the_tweaks:crushed_blackstone_block_9x`, `tamamo_the_tweaks:crushed_blackstone_block_8x`, `tamamo_the_tweaks:crushed_blackstone_block_9x`)

    shapedCompressed(`tamamo_the_tweaks:crushed_basalt_block_1x`, `exnihilosequentia:crushed_basalt`, `tamamo_the_tweaks:crushed_basalt_block_1x`)
    shapedCompressed(`tamamo_the_tweaks:crushed_basalt_block_2x`, `tamamo_the_tweaks:crushed_basalt_block_1x`, `tamamo_the_tweaks:crushed_basalt_block_2x`)
    shapedCompressed(`tamamo_the_tweaks:crushed_basalt_block_3x`, `tamamo_the_tweaks:crushed_basalt_block_2x`, `tamamo_the_tweaks:crushed_basalt_block_3x`)
    shapedCompressed(`tamamo_the_tweaks:crushed_basalt_block_4x`, `tamamo_the_tweaks:crushed_basalt_block_3x`, `tamamo_the_tweaks:crushed_basalt_block_4x`)
    shapedCompressed(`tamamo_the_tweaks:crushed_basalt_block_5x`, `tamamo_the_tweaks:crushed_basalt_block_4x`, `tamamo_the_tweaks:crushed_basalt_block_5x`)
    shapedCompressed(`tamamo_the_tweaks:crushed_basalt_block_6x`, `tamamo_the_tweaks:crushed_basalt_block_5x`, `tamamo_the_tweaks:crushed_basalt_block_6x`)
    shapedCompressed(`tamamo_the_tweaks:crushed_basalt_block_7x`, `tamamo_the_tweaks:crushed_basalt_block_6x`, `tamamo_the_tweaks:crushed_basalt_block_7x`)
    shapedCompressed(`tamamo_the_tweaks:crushed_basalt_block_8x`, `tamamo_the_tweaks:crushed_basalt_block_7x`, `tamamo_the_tweaks:crushed_basalt_block_8x`)
    shapedCompressed(`tamamo_the_tweaks:crushed_basalt_block_9x`, `tamamo_the_tweaks:crushed_basalt_block_8x`, `tamamo_the_tweaks:crushed_basalt_block_9x`)

    shapedCompressed(`tamamo_the_tweaks:crushed_end_stone_block_1x`, `exnihilosequentia:crushed_end_stone`, `tamamo_the_tweaks:crushed_end_stone_block_1x`)
    shapedCompressed(`tamamo_the_tweaks:crushed_end_stone_block_2x`, `tamamo_the_tweaks:crushed_end_stone_block_1x`, `tamamo_the_tweaks:crushed_end_stone_block_2x`)
    shapedCompressed(`tamamo_the_tweaks:crushed_end_stone_block_3x`, `tamamo_the_tweaks:crushed_end_stone_block_2x`, `tamamo_the_tweaks:crushed_end_stone_block_3x`)
    shapedCompressed(`tamamo_the_tweaks:crushed_end_stone_block_4x`, `tamamo_the_tweaks:crushed_end_stone_block_3x`, `tamamo_the_tweaks:crushed_end_stone_block_4x`)
    shapedCompressed(`tamamo_the_tweaks:crushed_end_stone_block_5x`, `tamamo_the_tweaks:crushed_end_stone_block_4x`, `tamamo_the_tweaks:crushed_end_stone_block_5x`)
    shapedCompressed(`tamamo_the_tweaks:crushed_end_stone_block_6x`, `tamamo_the_tweaks:crushed_end_stone_block_5x`, `tamamo_the_tweaks:crushed_end_stone_block_6x`)
    shapedCompressed(`tamamo_the_tweaks:crushed_end_stone_block_7x`, `tamamo_the_tweaks:crushed_end_stone_block_6x`, `tamamo_the_tweaks:crushed_end_stone_block_7x`)
    shapedCompressed(`tamamo_the_tweaks:crushed_end_stone_block_8x`, `tamamo_the_tweaks:crushed_end_stone_block_7x`, `tamamo_the_tweaks:crushed_end_stone_block_8x`)
    shapedCompressed(`tamamo_the_tweaks:crushed_end_stone_block_9x`, `tamamo_the_tweaks:crushed_end_stone_block_8x`, `tamamo_the_tweaks:crushed_end_stone_block_9x`)

    event.shapeless(Item.of('tamamo_the_tweaks:dust_block_1x', 9), 'tamamo_the_tweaks:dust_block_2x').id('tamamo_the_tweaks:split_dust_block_1x')
    event.shapeless(Item.of(`minecraft:netherite_scrap`, 9), `tamamo_the_tweaks:raw_netherite_scrap_block`).id(`tamamo_the_tweaks:netherite_scrap`)
    event.shapeless(Item.of(`minecraft:blaze_rod`, 9), `tamamo_the_tweaks:blaze_rod_block`).id(`tamamo_the_tweaks:split_blaze_rod`)
    event.shapeless(Item.of(`tamamo_the_tweaks:blaze_rod_block`, 9), `allthecompressed:blaze_rod_block_1x`).id(`tamamo_the_tweaks:split_blaze_rod_block`)
    //粉碎下界岩
    event.shapeless(Item.of('exnihilosequentia:crushed_netherrack', 9), 'tamamo_the_tweaks:crushed_netherrack_block_1x').id('tamamo_the_tweaks:split_crushed_netherrack_block_1x')
    event.shapeless(Item.of('tamamo_the_tweaks:crushed_netherrack_block_1x', 9), 'tamamo_the_tweaks:crushed_netherrack_block_2x').id('tamamo_the_tweaks:split_crushed_netherrack_block_2x')
    event.shapeless(Item.of('tamamo_the_tweaks:crushed_netherrack_block_2x', 9), 'tamamo_the_tweaks:crushed_netherrack_block_3x').id('tamamo_the_tweaks:split_crushed_netherrack_block_3x')
    event.shapeless(Item.of('tamamo_the_tweaks:crushed_netherrack_block_3x', 9), 'tamamo_the_tweaks:crushed_netherrack_block_4x').id('tamamo_the_tweaks:split_crushed_netherrack_block_4x')
    event.shapeless(Item.of('tamamo_the_tweaks:crushed_netherrack_block_4x', 9), 'tamamo_the_tweaks:crushed_netherrack_block_5x').id('tamamo_the_tweaks:split_crushed_netherrack_block_5x')
    event.shapeless(Item.of('tamamo_the_tweaks:crushed_netherrack_block_5x', 9), 'tamamo_the_tweaks:crushed_netherrack_block_6x').id('tamamo_the_tweaks:split_crushed_netherrack_block_6x')
    event.shapeless(Item.of('tamamo_the_tweaks:crushed_netherrack_block_6x', 9), 'tamamo_the_tweaks:crushed_netherrack_block_7x').id('tamamo_the_tweaks:split_crushed_netherrack_block_7x')
    event.shapeless(Item.of('tamamo_the_tweaks:crushed_netherrack_block_7x', 9), 'tamamo_the_tweaks:crushed_netherrack_block_8x').id('tamamo_the_tweaks:split_crushed_netherrack_block_8x')
    event.shapeless(Item.of('tamamo_the_tweaks:crushed_netherrack_block_8x', 9), 'tamamo_the_tweaks:crushed_netherrack_block_9x').id('tamamo_the_tweaks:split_crushed_netherrack_block_9x')
    //粉碎黑石
    event.shapeless(Item.of('exnihilosequentia:crushed_blackstone', 9), 'tamamo_the_tweaks:crushed_blackstone_block_1x').id('tamamo_the_tweaks:split_crushed_blackstone_block_1x')
    event.shapeless(Item.of('tamamo_the_tweaks:crushed_blackstone_block_1x', 9), 'tamamo_the_tweaks:crushed_blackstone_block_2x').id('tamamo_the_tweaks:split_crushed_blackstone_block_2x')
    event.shapeless(Item.of('tamamo_the_tweaks:crushed_blackstone_block_2x', 9), 'tamamo_the_tweaks:crushed_blackstone_block_3x').id('tamamo_the_tweaks:split_crushed_blackstone_block_3x')
    event.shapeless(Item.of('tamamo_the_tweaks:crushed_blackstone_block_3x', 9), 'tamamo_the_tweaks:crushed_blackstone_block_4x').id('tamamo_the_tweaks:split_crushed_blackstone_block_4x')
    event.shapeless(Item.of('tamamo_the_tweaks:crushed_blackstone_block_4x', 9), 'tamamo_the_tweaks:crushed_blackstone_block_5x').id('tamamo_the_tweaks:split_crushed_blackstone_block_5x')
    event.shapeless(Item.of('tamamo_the_tweaks:crushed_blackstone_block_5x', 9), 'tamamo_the_tweaks:crushed_blackstone_block_6x').id('tamamo_the_tweaks:split_crushed_blackstone_block_6x')
    event.shapeless(Item.of('tamamo_the_tweaks:crushed_blackstone_block_6x', 9), 'tamamo_the_tweaks:crushed_blackstone_block_7x').id('tamamo_the_tweaks:split_crushed_blackstone_block_7x')
    event.shapeless(Item.of('tamamo_the_tweaks:crushed_blackstone_block_7x', 9), 'tamamo_the_tweaks:crushed_blackstone_block_8x').id('tamamo_the_tweaks:split_crushed_blackstone_block_8x')
    event.shapeless(Item.of('tamamo_the_tweaks:crushed_blackstone_block_8x', 9), 'tamamo_the_tweaks:crushed_blackstone_block_9x').id('tamamo_the_tweaks:split_crushed_blackstone_block_9x')
    //粉碎玄武岩
    event.shapeless(Item.of('exnihilosequentia:crushed_basalt', 9), 'tamamo_the_tweaks:crushed_basalt_block_1x').id('tamamo_the_tweaks:split_crushed_basalt_block_1x')
    event.shapeless(Item.of('tamamo_the_tweaks:crushed_basalt_block_1x', 9), 'tamamo_the_tweaks:crushed_basalt_block_2x').id('tamamo_the_tweaks:split_crushed_basalt_block_2x')
    event.shapeless(Item.of('tamamo_the_tweaks:crushed_basalt_block_2x', 9), 'tamamo_the_tweaks:crushed_basalt_block_3x').id('tamamo_the_tweaks:split_crushed_basalt_block_3x')
    event.shapeless(Item.of('tamamo_the_tweaks:crushed_basalt_block_3x', 9), 'tamamo_the_tweaks:crushed_basalt_block_4x').id('tamamo_the_tweaks:split_crushed_basalt_block_4x')
    event.shapeless(Item.of('tamamo_the_tweaks:crushed_basalt_block_4x', 9), 'tamamo_the_tweaks:crushed_basalt_block_5x').id('tamamo_the_tweaks:split_crushed_basalt_block_5x')
    event.shapeless(Item.of('tamamo_the_tweaks:crushed_basalt_block_5x', 9), 'tamamo_the_tweaks:crushed_basalt_block_6x').id('tamamo_the_tweaks:split_crushed_basalt_block_6x')
    event.shapeless(Item.of('tamamo_the_tweaks:crushed_basalt_block_6x', 9), 'tamamo_the_tweaks:crushed_basalt_block_7x').id('tamamo_the_tweaks:split_crushed_basalt_block_7x')
    event.shapeless(Item.of('tamamo_the_tweaks:crushed_basalt_block_7x', 9), 'tamamo_the_tweaks:crushed_basalt_block_8x').id('tamamo_the_tweaks:split_crushed_basalt_block_8x')
    event.shapeless(Item.of('tamamo_the_tweaks:crushed_basalt_block_8x', 9), 'tamamo_the_tweaks:crushed_basalt_block_9x').id('tamamo_the_tweaks:split_crushed_basalt_block_9x')
    //粉碎末地石
    event.shapeless(Item.of('exnihilosequentia:crushed_end_stone', 9), 'tamamo_the_tweaks:crushed_end_stone_block_1x').id('tamamo_the_tweaks:split_crushed_end_stone_block_1x')
    event.shapeless(Item.of('tamamo_the_tweaks:crushed_end_stone_block_1x', 9), 'tamamo_the_tweaks:crushed_end_stone_block_2x').id('tamamo_the_tweaks:split_crushed_end_stone_block_2x')
    event.shapeless(Item.of('tamamo_the_tweaks:crushed_end_stone_block_2x', 9), 'tamamo_the_tweaks:crushed_end_stone_block_3x').id('tamamo_the_tweaks:split_crushed_end_stone_block_3x')
    event.shapeless(Item.of('tamamo_the_tweaks:crushed_end_stone_block_3x', 9), 'tamamo_the_tweaks:crushed_end_stone_block_4x').id('tamamo_the_tweaks:split_crushed_end_stone_block_4x')
    event.shapeless(Item.of('tamamo_the_tweaks:crushed_end_stone_block_4x', 9), 'tamamo_the_tweaks:crushed_end_stone_block_5x').id('tamamo_the_tweaks:split_crushed_end_stone_block_5x')
    event.shapeless(Item.of('tamamo_the_tweaks:crushed_end_stone_block_5x', 9), 'tamamo_the_tweaks:crushed_end_stone_block_6x').id('tamamo_the_tweaks:split_crushed_end_stone_block_6x')
    event.shapeless(Item.of('tamamo_the_tweaks:crushed_end_stone_block_6x', 9), 'tamamo_the_tweaks:crushed_end_stone_block_7x').id('tamamo_the_tweaks:split_crushed_end_stone_block_7x')
    event.shapeless(Item.of('tamamo_the_tweaks:crushed_end_stone_block_7x', 9), 'tamamo_the_tweaks:crushed_end_stone_block_8x').id('tamamo_the_tweaks:split_crushed_end_stone_block_8x')
    event.shapeless(Item.of('tamamo_the_tweaks:crushed_end_stone_block_8x', 9), 'tamamo_the_tweaks:crushed_end_stone_block_9x').id('tamamo_the_tweaks:split_crushed_end_stone_block_9x')
    function shapedSlab(materials) {
        event.shaped("#forge:planks/" + materials, [
            'a',
            'a'
        ],
            { a: "minecraft:" + materials + "_slab" }
        ).id("tamamo_the_tweaks:" + materials + "_slab_to_planks")
    }
    shapedSlab('oak')
    shapedSlab('spruce')
    shapedSlab('birch')
    shapedSlab('jungle')
    shapedSlab('acacia')
    shapedSlab('dark_oak')
    event.shaped(`tamamo_the_tweaks:armor_base`, [
        'ABA',
        'BCB',
        'ABA'
    ],
        {
            A: 'minecraft:string',
            B: 'minecraft:leather',
            C: 'minecraft:amethyst_shard'
        }
    ).id(`tamamo_the_tweaks:armor_base`)
    event.remove({ id: 'minecraft:leather_helmet' })
    event.remove({ id: 'minecraft:leather_chestplate' })
    event.remove({ id: 'minecraft:leather_leggings' })
    event.remove({ id: 'minecraft:leather_boots' })

    event.remove({ id: 'minecraft:iron_helmet' })
    event.remove({ id: 'minecraft:iron_chestplate' })
    event.remove({ id: 'minecraft:iron_leggings' })
    event.remove({ id: 'minecraft:iron_boots' })

    event.remove({ id: 'minecraft:golden_helmet' })
    event.remove({ id: 'minecraft:golden_chestplate' })
    event.remove({ id: 'minecraft:golden_leggings' })
    event.remove({ id: 'minecraft:golden_boots' })

    event.remove({ id: 'minecraft:diamond_helmet' })
    event.remove({ id: 'minecraft:diamond_chestplate' })
    event.remove({ id: 'minecraft:diamond_leggings' })
    event.remove({ id: 'minecraft:diamond_boots' })
    event.shaped(`minecraft:leather_helmet`, [
        'AAA',
        'ABA'
    ],
        {
            A: 'minecraft:leather',
            B: 'tamamo_the_tweaks:armor_base'
        }
    ).id(`tamamo_the_tweaks:lether_helment`)
    event.shaped(`minecraft:leather_chestplate`, [
        'ABA',
        'AAA',
        'AAA'
    ],
        {
            A: 'minecraft:leather',
            B: 'tamamo_the_tweaks:armor_base'
        }
    ).id(`tamamo_the_tweaks:lether_chestplate`)
    event.shaped(`minecraft:leather_leggings`, [
        'AAA',
        'ABA',
        'A A'
    ],
        {
            A: 'minecraft:leather',
            B: 'tamamo_the_tweaks:armor_base'
        }
    ).id(`tamamo_the_tweaks:lether_leggings`)
    event.shaped(`minecraft:leather_boots`, [
        'ABA',
        'A A'
    ],
        {
            A: 'minecraft:leather',
            B: 'tamamo_the_tweaks:armor_base'
        }
    ).id(`tamamo_the_tweaks:lether_boots`)
    event.smithing('minecraft:iron_helmet', 'minecraft:leather_helmet', 'minecraft:iron_ingot')
    event.smithing('minecraft:golden_helmet', 'minecraft:leather_helmet', 'minecraft:gold_ingot')
    event.smithing('minecraft:diamond_helmet', 'minecraft:iron_helmet', 'minecraft:diamond')

    event.smithing('minecraft:iron_chestplate', 'minecraft:leather_chestplate', 'minecraft:iron_ingot')
    event.smithing('minecraft:golden_chestplate', 'minecraft:leather_chestplate', 'minecraft:gold_ingot')
    event.smithing('minecraft:diamond_chestplate', 'minecraft:iron_chestplate', 'minecraft:diamond')

    event.smithing('minecraft:iron_leggings', 'minecraft:leather_leggings', 'minecraft:iron_ingot')
    event.smithing('minecraft:golden_leggings', 'minecraft:leather_leggings', 'minecraft:gold_ingot')
    event.smithing('minecraft:diamond_leggings', 'minecraft:iron_leggings', 'minecraft:diamond')

    event.smithing('minecraft:iron_boots', 'minecraft:leather_boots', 'minecraft:iron_ingot')
    event.smithing('minecraft:golden_boots', 'minecraft:leather_boots', 'minecraft:gold_ingot')
    event.smithing('minecraft:diamond_boots', 'minecraft:iron_boots', 'minecraft:diamond')

    event.smithing('mekanism:hazmat_mask', 'minecraft:iron_helmet', 'minecraft:orange_wool').id(`mekanism:hazmat_mask`)
    event.smithing('mekanism:hazmat_gown', 'minecraft:iron_chestplate', 'minecraft:orange_wool').id(`mekanism:hazmat_gown`)
    event.smithing('mekanism:hazmat_pants', 'minecraft:iron_leggings', 'minecraft:orange_wool').id(`mekanism:hazmat_pants`)
    event.smithing('mekanism:hazmat_boots', 'minecraft:iron_boots', 'thermal:cured_rubber').id(`mekanism:hazmat_boots`)
    event.shaped(`tamamo_the_tweaks:plate_die`, [
        ' A ',
        'ABA',
        ' A '
    ],
        {
            A: '#forge:plates/invar',
            B: '#forge:plates'
        }
    ).id(`tamamo_the_tweaks:plate_die`)

})