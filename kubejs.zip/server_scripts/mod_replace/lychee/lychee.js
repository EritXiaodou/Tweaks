ServerEvents.recipes(event => {
    event.custom({
        "type": "lychee:item_inside",
        "item_in": { "item": "exnihilosequentia:dust" },
        "block_in": { "blocks": ["minecraft:water"] },
        "post": { "type": "drop_item", "item": "minecraft:clay" }
    })
    event.custom({
        "type": "lychee:item_inside",
        "item_in": { "tag": "minecraft:sand" },
        "block_in": { "blocks": ["exnihilosequentia:witch_water"] },
        "post": { "type": "drop_item", "item": "minecraft:soul_sand" }
    })
    event.custom({
        "type": "lychee:block_interacting",
        "item_in": { "tag": "ftbsba:hammers" },
        "block_in": "cobblestone",
        "contextual": { "type": "is_sneaking", "description": "shift + right click" },
        "post": [
            { "type": "place", "block": "gravel" },
            { "type": "damage_item" }
        ]
    })
    event.custom({
        "type": "lychee:block_interacting",
        "item_in": { "tag": "ftbsba:hammers" },
        "block_in": "gravel",
        "contextual": { "type": "is_sneaking", "description": "shift + right click" },
        "post": [
            { "type": "place", "block": "sand" },
            { "type": "damage_item" }
        ]
    })
    event.custom({
        "type": "lychee:block_interacting",
        "item_in": { "tag": "ftbsba:hammers" },
        "block_in": { "tag": "forge:sand" },
        "contextual": { "type": "is_sneaking", "description": "shift + right click" },
        "post": [
            { "type": "place", "block": "exnihilosequentia:dust" },
            { "type": "damage_item" }
        ]
    })
    event.custom({
        "type": "lychee:block_interacting",
        "item_in": { "tag": "ftbsba:hammers" },
        "block_in": { "tag": "forge:cobbled_block" },
        "contextual": { "type": "is_sneaking", "description": "shift + right click" },
        "post": [
            { "type": "place", "block": "allthecompressed:cobblestone_block_1x" },
            { "type": "damage_item" }
        ]
    })
    event.custom({
        "type": "lychee:block_interacting",
        "item_in": { "tag": "ftbsba:hammers" },
        "block_in": { "tag": "forge:graveld_block" },
        "contextual": { "type": "is_sneaking", "description": "shift + right click" },
        "post": [
            { "type": "place", "block": "allthecompressed:gravel_block_1x" },
            { "type": "damage_item" }
        ]
    })
    event.custom({
        "type": "lychee:block_interacting",
        "item_in": { "tag": "ftbsba:hammers" },
        "block_in": { "tag": "forge:sanded_block" },
        "contextual": { "type": "is_sneaking", "description": "shift + right click" },
        "post": [
            { "type": "place", "block": "allthecompressed:sand_block_1x" },
            { "type": "damage_item" }
        ]
    })
    event.custom({
        "type": "lychee:block_interacting",
        "item_in": { "tag": "ftbsba:hammers" },
        "block_in": { "tag": "forge:dusted_block" },
        "contextual": { "type": "is_sneaking", "description": "shift + right click" },
        "post": [
            { "type": "place", "block": "tamamo_the_tweaks:dust_block_1x" },
            { "type": "damage_item" }
        ]
    })
    event.custom({
        "type": "lychee:block_interacting",
        "item_in": { "tag": "ftbsba:hammers" },
        "block_in": { "tag": "forge:storage_blocks/red_sand" },
        "contextual": { "type": "is_sneaking", "description": "shift + right click" },
        "post": [
            { "type": "place", "block": "tamamo_the_tweaks:dust_block_1x" },
            { "type": "damage_item" }
        ]
    })

    event.custom({
        "type": "lychee:block_interacting",
        "item_in": [
            {
                "item": "minecraft:flint"
            }
        ],
        "block_in": "gravel",
        "contextual": {
            "type": "is_sneaking",
            "description": "shift + right click"
        },
        "post": [
            {
                "type": "random",
                "rolls": {
                    "min": 0,
                    "max": 1
                },
                "entries": [
                    {
                        "weight": 5,
                        "type": "drop_item",
                        "item": "gold_nugget"
                    },
                    {
                        "weight": 10,
                        "type": "drop_item",
                        "item": "iron_nugget",
                    },
                    {
                        "weight": 50,
                        "type": "drop_item",
                        "item": "flint"
                    },
                    {
                        "weight": 35,
                        "type": "drop_item",
                        "item": "bone_meal"
                    }
                ]
            },
            {
                "type": "damage_item"
            },
            {
                "type": "execute",
                "command": "setblock ~ ~ ~ air",
                "hide": true
            }

        ]
    })
})