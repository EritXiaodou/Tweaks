ServerEvents.recipes(event => {
    event.remove({ id: 'mekanism:evaporating/brine' })
    event.remove({ id: 'mekanism:evaporating/lithium' })
    event.remove({ id: 'mekanism:separator/water' })
    event.remove({ id: 'mekaevolution:absolute_control_circuit' })
    event.remove({ id: 'mekaevolution:supreme_control_circuit' })
    event.remove({ id: 'mekaevolution:cosmic_control_circuit' })
    event.remove({ id: 'mekaevolution:infinite_control_circuit' })
    event.remove({ id: `/mekanism:pigment_extracting/banner/` })
    event.remove({ id: `/mekanism:pigment_extracting/concrete/` })
    event.remove({ id: `/mekanism:pigment_extracting/concrete_powder/` })
    event.remove({ id: `/mekanism:pigment_extracting/terracotta/` })
    event.remove({ output: `mekanism:ingot_uranium` })

    let atomic = 'alloy_atomic'
    let absolute = 'absolute'
    let supreme = 'supreme'
    let cosmic = 'cosmic'
    let infinite = 'infinite'

    event.remove({ output: `mekaevolution:absolute_energy_cube` })
    event.remove({ output: `mekaevolution:supreme_energy_cube` })
    event.remove({ output: `mekaevolution:cosmic_energy_cube` })
    event.remove({ output: `mekaevolution:infinite_energy_cube` })

    event.replaceInput({ output: 'mekaevolution:absolute_universal_cable' }, 'mekanism:alloy_atomic', 'tamamo_the_tweaks:alloy_absolute')
    event.replaceInput({ output: 'mekaevolution:absolute_logistical_transporter' }, 'mekanism:alloy_atomic', 'tamamo_the_tweaks:alloy_absolute')
    event.replaceInput({ output: 'mekaevolution:absolute_mechanical_pipe' }, 'mekanism:alloy_atomic', 'tamamo_the_tweaks:alloy_absolute')

    event.replaceInput({ output: 'mekaevolution:supreme_universal_cable' }, 'mekanism:alloy_atomic', 'tamamo_the_tweaks:alloy_supreme')
    event.replaceInput({ output: 'mekaevolution:supreme_logistical_transporter' }, 'mekanism:alloy_atomic', 'tamamo_the_tweaks:alloy_supreme')
    event.replaceInput({ output: 'mekaevolution:supreme_mechanical_pipe' }, 'mekanism:alloy_atomic', 'tamamo_the_tweaks:alloy_supreme')

    event.replaceInput({ output: 'mekaevolution:cosmic_universal_cable' }, 'mekanism:alloy_atomic', 'tamamo_the_tweaks:alloy_cosmic')
    event.replaceInput({ output: 'mekaevolution:cosmic_logistical_transporter' }, 'mekanism:alloy_atomic', 'tamamo_the_tweaks:alloy_cosmic')
    event.replaceInput({ output: 'mekaevolution:cosmic_mechanical_pipe' }, 'mekanism:alloy_atomic', 'tamamo_the_tweaks:alloy_cosmic')

    event.replaceInput({ output: 'mekaevolution:infinite_universal_cable' }, 'mekanism:alloy_atomic', 'tamamo_the_tweaks:alloy_infinite')
    event.replaceInput({ output: 'mekaevolution:infinite_logistical_transporter' }, 'mekanism:alloy_atomic', 'tamamo_the_tweaks:alloy_infinite')
    event.replaceInput({ output: 'mekaevolution:infinite_mechanical_pipe' }, 'mekanism:alloy_atomic', 'tamamo_the_tweaks:alloy_infinite')

    event.replaceInput({ output: 'mekanism:steel_casing' }, '#c:glass_blocks', 'minecraft:iron_bars')

    event.recipes.mekanismEnriching('mekanism:yellow_cake_uranium', '#forge:ingots/uranium')
    event.recipes.mekanismEnriching('tamamo_the_tweaks:enriched_copper', '#forge:dusts/copper')
    event.recipes.mekanismEnriching('tamamo_the_tweaks:enriched_yellow_cake_uranium', '#forge:yellow_cake_uranium')
    event.recipes.mekanismMetallurgicInfusing('#forge:ingots/bronze', '#forge:ingots/tin', 'kubejs:copper')
    event.custom(
        {
            "type": "mekanism:infusion_conversion",
            "input": { "ingredient": { "item": "tamamo_the_tweaks:enriched_copper" } },
            "output": { "amount": 80, "infuse_type": "kubejs:copper" }
        }
    )
    event.custom(
        {
            "type": "mekanism:oxidizing",
            "input": { "ingredient": { "item": "tamamo_the_tweaks:enriched_yellow_cake_uranium" } },
            "output": { "amount": 800, "gas": "mekanism:uranium_oxide" }
        }
    ).id('mekanism:oxidizing_yellow_cake_uranium')

    event.shaped(Item.of('mekaevolution:absolute_control_circuit'), [
        ['tamamo_the_tweaks:alloy_absolute', 'mekanism:ultimate_control_circuit', 'tamamo_the_tweaks:alloy_absolute']
    ]).id('mekaevolution:absolute_control_circuit')
    event.shaped(Item.of('mekaevolution:supreme_control_circuit'), [
        ['tamamo_the_tweaks:alloy_supreme', 'mekaevolution:absolute_control_circuit', 'tamamo_the_tweaks:alloy_supreme']
    ]).id('mekaevolution:supreme_control_circuit')
    event.shaped(Item.of('mekaevolution:cosmic_control_circuit'), [
        ['tamamo_the_tweaks:alloy_cosmic', 'mekaevolution:supreme_control_circuit', 'tamamo_the_tweaks:alloy_cosmic']
    ]).id('mekaevolution:cosmic_control_circuit')
    event.shaped(Item.of('mekaevolution:infinite_control_circuit'), [
        ['tamamo_the_tweaks:alloy_infinite', 'mekaevolution:cosmic_control_circuit', 'tamamo_the_tweaks:alloy_infinite']
    ]).id('mekaevolution:infinite_control_circuit')

    event.shaped(Item.of('tamamo_the_tweaks:absolute_upgrade'), [
        ['mekanism:energy_tablet', '#forge:glass', 'mekanism:energy_tablet'],
        ['tamamo_the_tweaks:alloy_absolute', 'mekanism:ultimate_control_circuit', 'tamamo_the_tweaks:alloy_absolute'],
        ['mekanism:energy_tablet', '#forge:glass', 'mekanism:energy_tablet']
    ]).id('tamamo_the_tweaks:absolute_upgrade')
    event.shaped(Item.of('tamamo_the_tweaks:supreme_upgrade'), [
        ['mekanism:energy_tablet', '#forge:glass', 'mekanism:energy_tablet'],
        ['tamamo_the_tweaks:alloy_supreme', 'tamamo_the_tweaks:absolute_upgrade', 'tamamo_the_tweaks:alloy_supreme'],
        ['mekanism:energy_tablet', '#forge:glass', 'mekanism:energy_tablet']
    ]).id('tamamo_the_tweaks:supreme_upgrade')
    event.shaped(Item.of('tamamo_the_tweaks:cosmic_upgrade'), [
        ['mekanism:energy_tablet', '#forge:glass', 'mekanism:energy_tablet'],
        ['tamamo_the_tweaks:alloy_cosmic', 'tamamo_the_tweaks:supreme_upgrade', 'tamamo_the_tweaks:alloy_cosmic'],
        ['mekanism:energy_tablet', '#forge:glass', 'mekanism:energy_tablet']
    ]).id('tamamo_the_tweaks:cosmic_upgrade')
    event.shaped(Item.of('tamamo_the_tweaks:infinite_upgrade'), [
        ['mekanism:energy_tablet', '#forge:glass', 'mekanism:energy_tablet'],
        ['tamamo_the_tweaks:alloy_infinite', 'tamamo_the_tweaks:cosmic_upgrade', 'tamamo_the_tweaks:alloy_infinite'],
        ['mekanism:energy_tablet', '#forge:glass', 'mekanism:energy_tablet']
    ]).id('tamamo_the_tweaks:infinite_upgrade')
    event.custom(
        {
            "type": "mekanism:infusion_conversion",
            "input": { "ingredient": { "item": 'tamamo_the_tweaks:enriched_copper' } },
            "output": { "amount": 80, "infuse_type": "kubejs:copper" }
        }
    ).id("tamamo_the_tweaks:conversion_enriched_copper")
    event.custom(
        {
            "type": "mekanism:infusion_conversion",
            "input": { "ingredient": { "tag": 'forge:dusts/copper' } },
            "output": { "amount": 10, "infuse_type": "kubejs:copper" }
        }
    ).id("tamamo_the_tweaks:conversion_copper")

    event.custom(
        {
            "type": "mekanism:rotary",
            "fluidInput": { "amount": 1, "fluid": "kubejs:echo_essence" },
            "fluidOutput": { "amount": 1, "fluid": "kubejs:echo_essence" },
            "gasInput": { "amount": 1, "gas": "tamamo_the_tweaks:echo_gas" },
            "gasOutput": { "amount": 1, "gas": "tamamo_the_tweaks:echo_gas" }
        }
    )
    event.custom(
        {
            "type": "mekanism:rotary",
            "fluidOutput": { "amount": 1, "fluid": "minecraft:water" },
            "gasInput": { "amount": 1, "gas": "mekanism:spent_nuclear_waste" }
        }
    )
    event.custom(
        {
            "type": "mekanism:rotary",
            "fluidInput": { "amount": 1, "fluid": "industrialforegoing:ether_gas" },
            "fluidOutput": { "amount": 1, "fluid": "industrialforegoing:ether_gas" },
            "gasInput": { "amount": 1, "gas": "tamamo_the_tweaks:ether_gas" },
            "gasOutput": { "amount": 1, "gas": "tamamo_the_tweaks:ether_gas" }
        }
    )
    event.custom(
        {
            "type": "mekanism:rotary",
            "fluidInput": { "amount": 1, "fluid": "kubejs:cryotheum" },
            "fluidOutput": { "amount": 1, "fluid": "kubejs:cryotheum" },
            "gasInput": { "amount": 1, "gas": "tamamo_the_tweaks:cryotheum" },
            "gasOutput": { "amount": 1, "gas": "tamamo_the_tweaks:cryotheum" }
        }
    )
    event.custom(
        {
            "type": "mekanism:separating",
            "input": { "amount": 2, "fluid": "minecraft:water" },
            "leftGasOutput": { "amount": 2, "gas": "mekanism:hydrogen" },
            "rightGasOutput": { "amount": 1, "gas": "mekanism:oxygen" }
        }
    )
    event.custom(
        {
            "type": "mekanism:separating",
            "input": { "amount": 1000, "fluid": "exnihilosequentia:sea_water" },
            "leftGasOutput": { "amount": 2, "gas": "tamamo_the_tweaks:echo_gas" },
            "rightGasOutput": { "amount": 1, "gas": "mekanism:oxygen" }
        }
    )
    event.custom(
        {
            "type": "mekanism:reaction",
            "duration": 400,
            "fluidInput": { "amount": 150, "fluid": "industrialforegoing:ether_gas" },
            "gasInput": { "amount": 200, "gas": "mekanism:lithium" },
            "gasOutput": { "amount": 200, "gas": "mekanism:brine" },
            "itemInput": { "amount": 1, "ingredient": { "item": 'mekanism:alloy_atomic' } },
            "itemOutput": { "count": 1, "item": 'tamamo_the_tweaks:alloy_absolute' }
        }
    ).id('tamamo_the_tweaks:alloy_absolute')
    event.custom(
        {
            "type": "mekanism:reaction",
            "duration": 600,
            "fluidInput": { "amount": 150, "fluid": 'kubejs:echo_essence' },
            "gasInput": { "amount": 150, "gas": "mekanismgenerators:deuterium" },
            "gasOutput": { "amount": 100, "gas": "mekanism:oxygen" },
            "itemInput": { "amount": 1, "ingredient": { "item": 'tamamo_the_tweaks:alloy_absolute' } },
            "itemOutput": { "count": 1, "item": 'tamamo_the_tweaks:alloy_supreme' }
        }
    ).id('tamamo_the_tweaks:alloy_supreme')
    let QuartzChicken = Item.of('chickens:chicken_item', '{ChickenType:{id:"chickens:quartz_chicken"}}')
    let SilverChicken = Item.of('chickens:chicken_item')

    event.recipes.mekanismCombining(QuartzChicken, SilverChicken, 'allthecompressed:quartz_block_3x')
    function Crush(result, input) {
        event.recipes.mekanismCrushing(result, input)
    }
    Crush('#forge:dusts/sulfur', '#forge:gems/sulfur')

    event.custom({ "type": "mekanism:evaporating", "input": { "amount": 100, "fluid": "minecraft:water" }, "output": { "amount": 1, "fluid": "mekanism:brine" } }).id('tamamo_the_tweaks:brine')
    event.custom({ "type": "mekanism:evaporating", "input": { "amount": 100, "fluid": "mekanism:brine" }, "output": { "amount": 1, "fluid": "mekanism:lithium" } }).id('tamamo_the_tweaks:lithium')
    event.custom({ "type": "mekanism:fission", "input": { "gas": "mekanismgenerators:fusion_fuel", "amount": 1 }, "output": { "gas": "mekanism:nuclear_waste", "amount": 10 }, "heat": 0 }).id('tamamo_the_tweaks:nuclear_waste')
    /*event.custom({
        "type": "mekanism:fluid_coolant",
        "input": {
            "fluid": "kubejs:cryotheum",
            "amount": 1
        },
        "output": {
            "id": "mekanism:steam",
            "amount": 1
        },
        "thermalEnthalpy": 10,
        "conductivity": 1,
        "efficiency": 0.2
    })*/
})