BlockEvents.rightClicked(event => {
    const { hand, player } = event
    if (hand != 'MAIN_HAND') return
    if (!player.isShiftKeyDown()) return
    if (event.item == "tamamo_the_tweaks:absolute_upgrade" && event.block == 'mekanism:ultimate_energy_cube') {
        event.server.runCommandSilent(`execute in minecraft:overworld run data get entity @r`)
        event.server.runCommandSilent(`setblock ${event.getBlock().getX()} ${event.getBlock().getY()} ${event.getBlock().getZ()} mekaevolution:absolute_energy_cube`)
        event.getItem().setCount(event.item.getCount() - 1)
    }
    if (event.item == "tamamo_the_tweaks:supreme_upgrade" && event.block == 'mekaevolution:absolute_energy_cube') {
        event.server.runCommandSilent(`execute in minecraft:overworld run data get entity @r`)
        event.server.runCommandSilent(`setblock ${event.getBlock().getX()} ${event.getBlock().getY()} ${event.getBlock().getZ()} mekaevolution:supreme_energy_cube`)
        event.getItem().setCount(event.item.getCount() - 1)
    }
    if (event.item == "tamamo_the_tweaks:cosmic_upgrade" && event.block == 'mekaevolution:supreme_energy_cube') {
        event.server.runCommandSilent(`execute in minecraft:overworld run data get entity @r`)
        event.server.runCommandSilent(`setblock ${event.getBlock().getX()} ${event.getBlock().getY()} ${event.getBlock().getZ()} mekaevolution:cosmic_energy_cube`)
        event.getItem().setCount(event.item.getCount() - 1)
    }
    if (event.item == "tamamo_the_tweaks:infinite_upgrade" && event.block == 'mekaevolution:cosmic_energy_cube') {
        event.server.runCommandSilent(`execute in minecraft:overworld run data get entity @r`)
        event.server.runCommandSilent(`setblock ${event.getBlock().getX()} ${event.getBlock().getY()} ${event.getBlock().getZ()} mekaevolution:infinite_energy_cube`)
        event.getItem().setCount(event.item.getCount() - 1)
    }
    player.swing()
})
