ServerEvents.recipes(event => {
    event.remove({ id: `/powah:energizing/allthecompressed/blazing_crystal/` })
    // .energizing([inputs, ...], output, energy)
    event.recipes.powah.energizing(
        [
            Item.of('tamamo_the_tweaks:alloy_cosmic'),
            Item.of('thermalendergy:stellarium_ingot', 3),
            Item.of('mekanism:pellet_antimatter', 2)
        ],
        "tamamo_the_tweaks:alloy_infinite", 9000000000
    )
    event.recipes.powah.energizing(
        [
            Item.of('tamamo_the_tweaks:absolute_upgrade_augment'),
            Item.of('tamamo_the_tweaks:alloy_supreme', 4),
            Item.of('tamamo_the_tweaks:supreme_upgrade')
        ],
        "tamamo_the_tweaks:supreme_upgrade_augment", 90000000
    )
    event.recipes.powah.energizing(
        [
            Item.of('minecraft:shulker_shell'),
            Item.of('minecraft:crying_obsidian', 4),
            Item.of('mekanism:pellet_antimatter')
        ],
        "allthemodium:unobtainium_shard", 90000
    )
    event.recipes.powah.energizing(
        [
            Item.of('#forge:ingots/uranium',2)
        ],
        'powah:uraninite', 4000
    )
    event.recipes.powah.energizing(
        [
            Item.of('#forge:storage_blocks/blaze')
        ],
        'powah:blazing_crystal_block', 90000
    )
})