ServerEvents.recipes(event => {
    event.remove({ id: `creativecrafter:creative_crafter` })
    event.remove({id: `/refinedstorage:coloring_recipes/`})
    event.remove({ type: `refinedstorage:cover_recipe` })
    
    event.shaped('creativecrafter:creative_crafter', [
        'ABA',
        'CDE',
        'AFA'
    ],
    {
        A: 'minecraft:netherite_block',
        B: 'minecraft:nether_star',
        C: 'minecraft:dragon_head',
        D: 'extrastorage:netherite_crafter',
        E: 'minecraft:elytra',
        F: 'minecraft:enchanted_golden_apple'
    }).id('tamamo_the_tweaks:creative_crafter')
})