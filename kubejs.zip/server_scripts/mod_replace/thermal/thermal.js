ServerEvents.recipes(event => {
    event.remove({ id: 'thermal_more:15x_component' })
    event.remove({ id: 'thermal_more:15x_component2' })
    event.remove({ id: 'thermal_more:20x_component' })
    event.remove({ id: 'thermal_more:25x_component' })
    event.remove({ id: 'thermal_more:30x_component' })
    event.remove({ id: 'thermal_more:35x_component' })
    event.remove({ id: 'thermal_more:40x_component' })
    event.remove({ id: 'thermal_more:40x_component2' })
    event.remove({ id: 'thermal_more:45x_component' })
    event.remove({ id: 'thermal_more:45x_component2' })
    event.remove({ id: 'thermal_more:50x_component' })
    event.remove({ id: 'thermal_more:50x_component2' })
    event.remove({ id: 'thermalendergy:vibrating_core' })
    event.replaceInput({ output: 'thermalendergy:endergy_upgrade_1' }, 'thermal:upgrade_augment_3', 'thermal_extra:upgrade_augment')
    event.replaceInput({ output: 'thermalendergy:melodium_ingot' }, '#forge:ingots/gold', '#forge:ingots/dragonsteel')
    event.replaceInput({ output: 'thermalendergy:stellarium_ingot' }, 'minecraft:clay_ball', 'industrialforegoing:pink_slime_ingot')
    event.replaceInput({ output: '#thermal:dynamos' }, 'minecraft:redstone', 'thermal:energy_cell')
    event.replaceInput({ output: 'thermal:cured_rubber' }, 'thermal:rubber', '#forge:rubber')

    //.energy-工作一次消耗的电量，可以说RF也可以是FE
    //.xp-工作一次获得的经验，不填就是没有
    //event.recipes.thermal.any('output', 'intput').energy(114514).xp(1919810)
    //红石熔炼炉
    event.recipes.thermal.furnace('minecraft:blackstone', 'minecraft:deepslate').xp(5).energy(2000)
    //锯木机
    event.recipes.thermal.sawmill('minecraft:oak_planks', 'minecraft:barrel').energy(2000)
    //磨粉机
    event.recipes.thermal.pulverizer('minecraft:gravel', '#forge:cobblestone').energy(2000)
    event.recipes.thermal.pulverizer(Item.of('#forge:dusts/nickel'), Item.of('#forge:ingots/nickel')).energy(4000)
    event.recipes.thermal.pulverizer(Item.of('#forge:dusts/tin'), Item.of('#forge:ingots/tin')).energy(4000)
    event.recipes.thermal.pulverizer(Item.of('#forge:dusts/silver'), Item.of('#forge:ingots/silver')).energy(4000)
    event.recipes.thermal.pulverizer(Item.of('#forge:dusts/lead'), Item.of('#forge:ingots/lead')).energy(4000)
    event.recipes.thermal.pulverizer(Item.of('#forge:dusts/zinc'), Item.of('#forge:ingots/zinc')).energy(4000)
    event.recipes.thermal.pulverizer([Item.of('minecraft:clay_ball', 4), Item.of('minecraft:clay_ball').withChance(0.15), Item.of('#forge:silicon').withChance(0.10)], Item.of('minecraft:clay')).energy(4000)
    //感应炉
    event.recipes.thermal.smelter('minecraft:charcoal', '#minecraft:logs').energy(2000)
    event.recipes.thermal.smelter('thermalendergy:prismalium_ingot', [Item.of('minecraft:prismarine_crystals', 3), Item.of('#forge:ingots/nickel', 2), Item.of('#forge:gems/fluorite', 8)]).energy(2000)
    event.recipes.thermal.smelter('tamamo_the_tweaks:alloy_cosmic', ['tamamo_the_tweaks:alloy_supreme', Item.of('thermalendergy:melodium_ingot', 4), Item.of('industrialforegoing:pink_slime_ingot', 8)]).energy(20000)
    //合金
    event.recipes.thermal.smelter(Item.of('#forge:ingots/steel'), [Item.of('thermal:coal_coke'), Item.of('#forge:ingots/iron')]).energy(2000)
    event.recipes.thermal.smelter(Item.of('#forge:ingots/bronze', 4), [Item.of('#forge:ingots/copper', 3), Item.of('#forge:ingots/tin')]).energy(2000)
    event.recipes.thermal.smelter(Item.of('#forge:ingots/electrum', 2), [Item.of('#forge:ingots/gold'), Item.of('#forge:ingots/silver')]).energy(2000)
    event.recipes.thermal.smelter(Item.of('#forge:ingots/invar', 3), [Item.of('#forge:ingots/iron', 2), Item.of('#forge:ingots/nickel')]).energy(2000)
    event.recipes.thermal.smelter(Item.of('#forge:ingots/constantan', 2), [Item.of('#forge:ingots/copper'), Item.of('#forge:ingots/nickel')]).energy(2000)
    event.recipes.thermal.smelter(Item.of('#forge:ingots/lumium', 4), [Item.of('#forge:ingots/tin', 3), Item.of('#forge:ingots/silver'), Item.of('minecraft:glowstone_dust', 4)]).energy(2000)
    event.recipes.thermal.smelter(Item.of('#forge:ingots/signalum', 4), [Item.of('#forge:ingots/copper', 3), Item.of('#forge:ingots/silver'), Item.of('minecraft:redstone', 4)]).energy(2000)
    event.recipes.thermal.smelter(Item.of('#forge:ingots/enderium', 4), [Item.of('#forge:ingots/lead', 3), Item.of('#forge:ingots/platinum'), Item.of('minecraft:ender_pearl', 2)]).energy(2000)
    event.recipes.thermal.smelter(Item.of('create:andesite_alloy'), [Item.of('minecraft:andesite'), Item.of('#forge:nuggets/iron')]).energy(2000)
    //合金块
    event.recipes.thermal.smelter(Item.of('#forge:storage_blocks/steel'), [Item.of('thermal:coal_coke_block'), Item.of('#forge:storage_blocks/iron')]).energy(18000)
    event.recipes.thermal.smelter(Item.of('#forge:storage_blocks/bronze', 4), [Item.of('#forge:storage_blocks/copper', 3), Item.of('#forge:storage_blocks/tin')]).energy(18000)
    event.recipes.thermal.smelter(Item.of('#forge:storage_blocks/electrum', 2), [Item.of('#forge:storage_blocks/gold'), Item.of('#forge:storage_blocks/silver')]).energy(18000)
    event.recipes.thermal.smelter(Item.of('#forge:storage_blocks/invar', 3), [Item.of('#forge:storage_blocks/iron', 2), Item.of('#forge:storage_blocks/nickel')]).energy(18000)
    event.recipes.thermal.smelter(Item.of('#forge:storage_blocks/constantan', 2), [Item.of('#forge:storage_blocks/copper'), Item.of('#forge:storage_blocks/nickel')]).energy(18000)
    event.recipes.thermal.smelter(Item.of('#forge:storage_blocks/lumium', 4), [Item.of('#forge:storage_blocks/tin', 3), Item.of('#forge:storage_blocks/silver'), Item.of('minecraft:glowstone_dust', 4)]).energy(18000)
    event.recipes.thermal.smelter(Item.of('#forge:storage_blocks/signalum', 4), [Item.of('#forge:storage_blocks/copper', 3), Item.of('#forge:storage_blocks/silver'), Item.of('minecraft:redstone_block', 4)]).energy(18000)
    event.recipes.thermal.smelter(Item.of('#forge:storage_blocks/enderium', 4), [Item.of('#forge:storage_blocks/lead', 3), Item.of('#forge:storage_blocks/platinum'), Item.of('minecraft:ender_pearl', 2)]).energy(18000)
    event.recipes.thermal.smelter(Item.of('#forge:storage_blocks/andesite_alloy'), [Item.of('#forge:storage_blocks/andesite'), Item.of('#forge:storage_blocks/iron')]).energy(18000)
    //离心分离机
    event.recipes.thermal.centrifuge(Fluid.of('thermal:crude_oil', 50), 'thermal:tar').energy(2000)
    //多驱冲压机
    event.recipes.thermal.press(Fluid.of('minecraft:water', 10), 'minecraft:sugar_cane').energy(2000)
    event.recipes.thermal.press(Item.of('minecraft:blaze_rod'), [Item.of('minecraft:blaze_powder', 5), 'thermal:chiller_rod_die']).energy(2000)
    function pressplate(input, result, energy) {
        event.recipes.thermal.press(Item.of("#forge:plates/" + input), "#forge:ingots/" + result).energy(energy)
    }
    function pressplatex9(input, result, energy) {
        event.recipes.thermal.press(Item.of("#forge:plates/" + input, 9), [Item.of("#forge:storage_blocks/" + result), `tamamo_the_tweaks:plate_die`]).energy(energy).keepIngredient(Item.of(`tamamo_the_tweaks:plate_die`).ignoreNBT)
    }
    function pressgear(input, result, energy) {
        event.recipes.thermal.press(Item.of("#forge:gears/" + input), [Item.of("#forge:ingots/" + result, 4), Item.of('thermal:press_gear_die')]).energy(energy)
    }
    //金属板
    pressplate('iron', 'iron', 1600)
    pressplate('gold', 'gold', 1600)
    event.recipes.thermal.press(Item.of('#forge:plates/diamond'), '#forge:gems/diamond').energy(1600)
    pressplate('copper', 'copper', 1600)
    pressplate('lead', 'lead', 1600)
    pressplate('nickel', 'nickel', 1600)
    pressplate('osmium', 'osmium', 1600)
    pressplate('silver', 'silver', 1600)
    pressplate('tin', 'tin', 1600)
    pressplate('zinc', 'zinc', 1600)
    //合金板
    pressplate('steel', 'steel', 1600)
    pressplate('invar', 'invar', 1600)
    pressplate('electrum', 'electrum', 1600)
    pressplate('bronze', 'bronze', 1600)
    pressplate('enderium', 'enderium', 1600)
    pressplate('lumium', 'lumium', 1600)
    pressplate('signalum', 'signalum', 1600)
    pressplate('constantan', 'constantan', 1600)
    pressplate('brass', 'brass', 1600)

    pressplatex9('iron', 'iron', 14400)
    pressplatex9('gold', 'gold', 14400)
    pressplatex9('diamond', 'diamond', 14400)
    pressplatex9('copper', 'copper', 14400)
    pressplatex9('lead', 'lead', 14400)
    pressplatex9('nickel', 'nickel', 14400)
    pressplatex9('osmium', 'osmium', 14400)
    pressplatex9('silver', 'silver', 14400)
    pressplatex9('tin', 'tin', 14400)
    pressplatex9('zinc', 'zinc', 14400)
    pressplatex9('steel', 'steel', 14400)
    pressplatex9('invar', 'invar', 14400)
    pressplatex9('electrum', 'electrum', 14400)
    pressplatex9('bronze', 'bronze', 14400)
    pressplatex9('enderium', 'enderium', 14400)
    pressplatex9('lumium', 'lumium', 14400)
    pressplatex9('signalum', 'signalum', 14400)
    pressplatex9('constantan', 'constantan', 14400)
    pressplatex9('brass', 'brass', 14400)

    pressgear('iron', 'iron', 2000)
    pressgear('gold', 'gold', 2000)
    event.recipes.thermal.press('#forge:gears/diamond', [Item.of('#forge:gems/diamond', 4), Item.of('thermal:press_gear_die')]).energy(2000)
    pressgear('copper', 'copper', 2000)
    pressgear('lead', 'lead', 2000)
    pressgear('nickel', 'nickel', 2000)
    pressgear('osmium', 'osmium', 2000)
    pressgear('silver', 'silver', 2000)
    pressgear('tin', 'tin', 2000)
    pressgear('zinc', 'zinc', 2000)
    pressgear('steel', 'steel', 2000)
    pressgear('invar', 'invar', 2000)
    pressgear('electrum', 'electrum', 2000)
    pressgear('bronze', 'bronze', 2000)
    pressgear('enderium', 'enderium', 2000)
    pressgear('lumium', 'lumium', 2000)
    pressgear('signalum', 'signalum', 2000)
    pressgear('constantan', 'constantan', 2000)
    pressgear('brass', 'brass', 2000)
    //熔岩炉
    event.recipes.thermal.crucible(Fluid.of('minecraft:water', 9000), 'minecraft:packed_ice').energy(2000)
    event.recipes.thermal.crucible(Fluid.of('tamamo_the_tweaks:echo_essence', 10), 'minecraft:echo_shard').energy(2000)
    event.recipes.thermal.crucible(Fluid.of('tamamo_the_tweaks:molten_steel', 144), '#forge:ingots/steel').energy(2000)
    event.recipes.thermal.crucible(Fluid.of('kubejs:cryotheum', 250), 'thermal:blizz_powder').energy(2000)
    event.recipes.thermal.crucible(Fluid.of('kubejs:pyrotheum', 250), 'tamamo_the_tweaks:pyrotheum_dust').energy(2000)
    //急速冷冻机
    event.recipes.thermal.chiller('thermal:tar', Fluid.of('thermal:crude_oil', 50)).energy(2000)
    event.recipes.thermal.chiller('thermal:blizz_powder', Fluid.of('kubejs:cryotheum', 250)).energy(2000)
    event.recipes.thermal.chiller('kubejs:pyrotheum_dust', Fluid.of('kubejs:pyrotheum', 250)).energy(2000)
    event.recipes.thermal.chiller('#forge:ingots/steel', [Fluid.of('tamamo_the_tweaks:molten_steel', 144), Item.of('thermal:chiller_ingot_cast')]).energy(2000)
    //流体精炼机
    event.recipes.thermal.refinery([Fluid.of('mekanism:hydrogen', 2), Fluid.of('mekanism:oxygen', 1)], Fluid.of('minecraft:water', 1)).energy(10)
    event.recipes.thermal.refinery(Item.of('thermal:rubber'), Fluid.of('thermal:latex', 100)).energy(1000)
    event.recipes.thermal.refinery(Item.of('thermal:rubber'), Fluid.of('industrialforegoing:latex', 100)).energy(1000)
    //药水酿造机
    event.recipes.thermal.brewer(Fluid.of('thermal:resin', 10), [Fluid.of('minecraft:water', 1000), '#forge:sapling']).energy(2000)
    event.recipes.thermal.brewer(Fluid.of('allthemodium:soul_lava', 1000), [Fluid.of('minecraft:lava', 1000), 'allthemodium:ancient_soulberries']).energy(2000)
    //流体灌装机
    //在添加Thermal_Extra mod的时候，流体容器槽最多可以装下2304000mB的流体
    event.recipes.thermal.bottler('minecraft:budding_amethyst', [Fluid.of('thermal:glowstone', 1000000), 'minecraft:amethyst_block']).energy(2000)
    event.recipes.thermal.bottler('minecraft:soul_sand', [Fluid.of('exnihilosequentia:witch_water', 100), 'minecraft:sand']).energy(2000)
    event.recipes.thermal.bottler('minecraft:soul_sand', [Fluid.of('exnihilosequentia:witch_water', 100), 'minecraft:red_sand']).energy(2000)
    //有机灌注器
    event.recipes.thermal.insolator([Item.of('thermal:rubberwood_log', 6).withChance(1), Item.of('thermal:rubberwood_sapling').withChance(1.1)], 'thermal:rubberwood_sapling').water(400).energy(60000)
    event.recipes.thermal.insolator(Item.of('minecraft:moss_block', 2).withChance(1), 'minecraft:muddy_mangrove_roots').water(1000).energy(2000)
    event.recipes.thermal.insolator(Item.of('allthemodium:ancient_soulberries', 2).withChance(1), 'allthemodium:ancient_soulberries').water(400).energy(2000)
    event.recipes.thermal.insolator([Item.of('integrateddynamics:menril_log', 8).withChance(1), Item.of('integrateddynamics:menril_sapling').withChance(1.1), Item.of('integrateddynamics:menril_berries').withChance(1.2)], 'integrateddynamics:menril_sapling').water(400).energy(2000)
    //结晶器
    event.recipes.thermal.crystallizer(Item.of('mekanism:crystal_gold').withChance(1.1), ['minecraft:oak_planks', Fluid.of('minecraft:water', 200)]).energy(2000)
    //热解炉
    event.recipes.thermal.pyrolyzer(Fluid.of('mekanism:hydrogen', 25), Item.of('#forge:sawdust', 8)).energy(10)
    event.recipes.thermal.pyrolyzer(Item.of('tamamo_the_tweaks:pyrotheum_dust').withChance(0.1), Item.of('powah:blazing_crystal_block')).energy(10)
    //machine catalyst
    //.primaryMod-主产物倍率
    //.secondaryMod-副产物倍率
    //.energyMod-能耗倍率
    //.minChance-最小消耗几率（本项目是按照升级插件来的，每个升级插件会将.useChance倍率*0.8，理论最低为1%，即消耗几率填0.0125）
    //.useChance-消耗几率
    event.recipes.thermal.pulverizer_catalyst('powah:crystal_nitro').primaryMod(13.5).secondaryMod(5.5).energyMod(0.25).minChance(0.20).useChance(0.25)//磨粉机催化剂
    event.recipes.thermal.smelter_catalyst('powah:crystal_nitro').primaryMod(13.5).secondaryMod(5.5).energyMod(0.25).minChance(0.20).useChance(0.25)//感应炉催化剂
    event.recipes.thermal.insolator_catalyst('powah:crystal_nitro').primaryMod(13.5).secondaryMod(5.5).energyMod(0.25).minChance(0.20).useChance(0.25)//有机灌注器催化剂
    //dynamo energy
    event.recipes.thermal.stirling_fuel('powah:crystal_nitro').energy(100000)//斯特林能源炉
    event.recipes.thermal.compression_fuel(Fluid.of('mekanism:ethene', 10)).energy(100000)//压缩能源炉
    event.recipes.thermal.magmatic_fuel(Fluid.of('mekanism:ethene', 100)).energy(250000)//热力能源炉
    event.recipes.thermal.magmatic_fuel(Fluid.of('kubejs:pyrotheum', 100)).energy(5000000)//热力能源炉
    event.recipes.thermal.numismatic_fuel('#mekanism:crystals').energy(40000)//通货能源炉
    event.recipes.thermal.lapidary_fuel('mekanism:fluorite_gem').energy(10000)//珠宝能源炉
    event.recipes.thermal.disenchantment_fuel('mekanism:teleportation_core').energy(1000000)//祛魔能源炉
    event.recipes.thermal.gourmand_fuel('cyclic:apple_bone').energy(64000)//饕餮能源炉
    //tree_extractor
    //树汁提取器的Slot_0为底部方块，Slot_1为顶部方块
    //Slot槽必须填写精确ID,不能使用任何标签
    //event.recipes.thermal.tree_extractor(output, Slot_0, Slot_1)
    event.recipes.thermal.tree_extractor(Fluid.of('thermal:resin', 100), 'minecraft:mangrove_log', 'minecraft:mangrove_leaves')
    //rock_gen
    function EventRecipeRockGen(adjacent, below, out, id) {
        let recipe = {
            "type": "thermal:rock_gen",
            "adjacent": adjacent,//右槽
            "result": Item.of(out)
        }
        if (below != '') {
            recipe.below = below
        }
        event.custom(recipe).id(id)
    }
    //EventRecipeRockGen(Slot_1, Slot_2, Output, Recipes ID)//经过测试Slot_0 也就是左槽只能是熔岩minecraft:lava
    //Slot槽必须填写精确ID,不能使用任何标签
    EventRecipeRockGen('exnihilosequentia:witch_water', 'minecraft:glowstone', 'minecraft:end_stone', 'tamamo_the_tweaks:endstone')
    EventRecipeRockGen('exnihilosequentia:witch_water', 'minecraft:redstone_block', 'minecraft:netherrack', 'tamamo_the_tweaks:netherrack')

    event.shaped('thermal:dynamo_gourmand', [
        " A ",
        "BCB",
        "DED"
    ], { A: 'thermal:rf_coil', B: '#forge:ingots/iron', C: '#forge:gears/copper', D: '#forge:ingots/tin', E: 'minecraft:redstone' }).id('thermal:dynamo_gourmand')
    event.shaped('thermal:fluid_duct', [
        "ABA"
    ], { A: '#forge:ingots/bronze', B: '#forge:ingots/steel' }).id('thermal:fluid_duct')
    event.shaped('thermal:energy_duct', [
        "ABA"
    ], { A: '#forge:ingots/lead', B: 'minecraft:redstone' }).id('thermal:energy_duct')
    event.shaped('thermal:energy_cell_frame', [
        'ABA',
        'B B',
        'ABA'
    ], { A: '#forge:ingots/lead', B: 'minecraft:redstone' }).id('tamamo_the_tweaks:eenergy_cell_frame')
    event.shaped('thermal:rf_coil_augment', [
        ' A ',
        'BCB',
        ' A '
    ], { A: '#forge:ingots/gold', B: '#forge:ingots/silver', C: 'thermal:rf_coil' }).id('thermal:rf_coil_augment')
    event.shaped('thermal:rf_coil_storage_augment', [
        ' B ',
        'ACA',
        ' A '
    ], { A: '#forge:ingots/gold', B: '#forge:ingots/silver', C: 'thermal:rf_coil' }).id('thermal:rf_coil_storage_augment')
    event.shaped('thermal:rf_coil_xfer_augment', [
        ' B ',
        'BCB',
        ' A '
    ], { A: '#forge:ingots/gold', B: '#forge:ingots/silver', C: 'thermal:rf_coil' }).id('thermal:rf_coil_xfer_augment')
    event.shaped('thermal:area_radius_augment', [
        ' A ',
        'BCB',
        ' A '
    ], { A: '#forge:gears/iron', B: '#forge:ingots/tin', C: 'thermal:redstone_servo' }).id('thermal:area_radius_augment')
    event.shaped('thermal:dynamo_throttle_augment', [
        ' A ',
        'ABA',
        ' A '
    ], { A: '#forge:nuggets/lead', B: '#forge:ingots/electrum' }).id('thermal:dynamo_throttle_augment')
    event.shaped('thermal:item_filter_augment', [
        ' A ',
        'ABA',
        ' A '
    ], { A: '#forge:nuggets/tin', B: '#forge:ingots/signalum' }).id('thermal:item_filter_augment')
    event.shaped('tamamo_the_tweaks:absolute_upgrade_augment', [
        'ABA',
        'DCD',
        'ABA'
    ], {
        A: 'tamamo_the_tweaks:alloy_absolute',
        B: 'tamamo_the_tweaks:absolute_upgrade',
        C: 'thermalendergy:endergy_upgrade_3',
        D: 'tamamo_the_tweaks:pyrotheum_dust'
    }).id('tamamo_the_tweaks:absolute_upgrade_augment')
})